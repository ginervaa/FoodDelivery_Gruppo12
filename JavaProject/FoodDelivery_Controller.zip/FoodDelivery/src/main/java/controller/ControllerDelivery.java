package controller;

import entity.*;

import java.util.ArrayList;
import java.util.List;

public class ControllerDelivery {

    // Variabile che serve a gestire la sessione.
    private static int idUtenteLoggato = 0;

    // Restituisce alla GUI (Boundary) la lista dei ristoranti di cui l'utente loggato è proprietario.
    public static List<String[]> ottieniRistoranti(){

        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // Il GestoreRistoranti restituisce una lista di ristoranti appartenenti all'utente loggato.
        List<Ristorante> ristoranti = gestoreRistoranti.ricercaRistorantiPerProprietario(idUtenteLoggato);

        // La lista da restituire alla Boundary, ogni elemento è una riga della tabella nel DB.
        List<String[]> righe = new ArrayList<>();

        // Converto la lista di elementi Ristorante in una lista di String, che verrà restituita alla Boundary.
        for (Ristorante ristorante : ristoranti) {

            String[] riga = new String[]{
                    String.valueOf(ristorante.getId()),
                    ristorante.getNome(),
                    ristorante.getDescrizione(),
                    ristorante.getIndirizzo()
            };

            righe.add(riga);
        }

        return righe;
    }

    // Realizza il caso d'uso "Creazione Profilo Ristorante".
    public static boolean creaProfiloRistorante(String nome,
                                                String descrizione,
                                                String indirizzo)
    {
        boolean esito;

        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // La creazione del ristorante restituisce esito positivo "true" se va a buon fine.
        esito = gestoreRistoranti.creaRistorante(idUtenteLoggato, nome, descrizione, indirizzo);

        return esito;
    }

    // Realizza il caso d'uso "Modifica Profilo Ristorante".
    public static boolean aggiornaProfiloRistorante(int idRistorante,
                                                    String nome,
                                                    String descrizione,
                                                    String indirizzo)
    {
        boolean esito;

        // Genero una istanza di GestoreRistoranti.
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Controllo per verificare che il ristorante restituito non sia nullo.
        if (ristorante == null){
            return false;
        }

        // L'aggiornamento dei dati del ristorante ritorna "true" se va a buon fine.
        esito = ristorante.aggiornaDatiRistorante(nome, descrizione, indirizzo);

        return esito;
    }

    // Realizza il caso d'uso "Gestione Menu Inserimento Piatto".
    public static boolean inserisciPiattoMenu(int idRistorante,
                                              String nome,
                                              String descrizione,
                                              float prezzo)
    {
        boolean esito;

        // Genero una istanza di GestoreRistoranti.
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Controllo per verificare che il ristorante restituito non sia nullo.
        if (ristorante == null){
            return false;
        }

        // Ottengo l'istanza del menu del ristorante ricercato.
        Menu menu = ristorante.getMenu();

        // L'inserimento del nuovo piatto restituisce true se va a buon fine.
        esito = menu.aggiungiPiatto(nome,descrizione,prezzo);

        return esito;
    }

    // Realizza il caso d'uso "Gestione Menu Modifica Piatto".
    public static boolean modificaPiattoMenu(int idRistorante,
                                             int idPiatto,
                                             String nome,
                                             String descrizione,
                                             float prezzo)
    {
        boolean esito;

        // Genero una istanza di GestoreRistoranti.
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Controllo per verificare che il ristorante restituito non sia nullo.
        if (ristorante == null){
            return false;
        }

        // Ottengo l'istanza del menu del ristorante ricercato.
        Menu menu = ristorante.getMenu();

        // L'aggiornamento dei dati del piatto restituisce "true" se va a buon fine.
        esito = menu.aggiornaDatiPiatto(idPiatto, nome, descrizione, prezzo);

        return esito;
    }

    // Realizza il caso d'uso "Gestione Menu Elimina Piatto".
    public static boolean eliminaPiattoMenu(int idRistorante,
                                            int idPiatto)
    {
        boolean esito;

        // Genero una istanza di GestoreRistoranti.
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Controllo per verificare che il ristorante restituito non sia nullo.
        if (ristorante == null){
            return false;
        }

        // Ottengo l'istanza del menu del ristorante ricercato.
        Menu menu = ristorante.getMenu();

        // Se l'eliminazione va a buon fine, restituisce "true".
        esito = menu.rimuoviPiatto(idPiatto);

        return esito;
    }

    // Realizza il caso d'uso "Accesso Utente".
    public static boolean login(String username,
                                String password,
                                RuoloUtente ruolo)
    {
        boolean esito;

        // Genero una istanza di GestoreUtenti.
        GestoreUtenti gestoreUtenti = new GestoreUtenti();

        // GestoreUtenti restituisce l'oggetto Utente ricercato in base all'username.
        Utente utente = gestoreUtenti.ricercaUtentePerUsername(username);

        // Controllo per verificare che l'Utente restituito non sia nullo.
        if (utente == null){
            return false;
        }

        // La verifica delle credenziali restituisce "true" se queste sono corrette.
        esito = utente.verificaCredenziali(username, password, ruolo);

        // Aggiorno la variabile interna del controller per gestire l'utente loggato.
        if (esito == true){
              idUtenteLoggato = utente.getId();
        }

        return esito;
    }

    // Restituisce alla GUI (Boundary) la lista dei piatti presenti nel menu di un ristorante.
    public static List<String[]> ottieniPiatti(int idRistorante){

        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Il GestoreRistoranti restituisce una lista di ristoranti appartenenti all'utente loggato.
        List<Piatto> piatti = ristorante.getMenu().getListaPiatti();

        // La lista da restituire alla Boundary, ogni elemento è una riga della tabella nel DB.
        List<String[]> righe = new ArrayList<>();

        // Converto la lista di elementi Piatto in una lista di String, che verrà restituita alla Boundary.
        for (Piatto piatto : piatti) {

            String[] riga = new String[]{
                    String.valueOf(piatto.getId()),
                    piatto.getNome(),
                    piatto.getDescrizione(),
                    piatto.getPrezzo()
            };

            righe.add(riga);
        }

        return righe;
    }

    // Permette all'utente di aggiungere un piatto al proprio carrello, fa parte del caso d'uso "Effettua Ordine".
    public static boolean aggiungiPiattoCarrello(int idPiatto)
    {
        boolean esito;

        // Genero una istanza di GestoreUtenti.
        GestoreUtenti gestoreUtenti = new GestoreUtenti();

        // GestoreUtenti restituisce l'oggetto Utente ricercato in base all'id.
        Utente utente = gestoreUtenti.ricercaUtentePerId(idUtenteLoggato);

        // Controllo per verificare che l'Utente restituito non sia null.
        if (utente == null){
            return false;
        }

        // Ottiene l'oggetto Carrello legato all'utente loggato attualmente.
        Carrello carrello = utente.getCarrello();

        // Controllo per verificare che il Carrello restituito non sia null.
        if(carrello == null){
            return false;
        }

        // Se l'aggiunta del piatto va a buon fine, restituisce "true".
        esito = carrello.aggiungiPiatto(idPiatto);

        return esito;
    }

    // Permette di inviare l'ordine, fa parte del caso d'uso "Effettua Ordine".
    public static boolean ordina(String indirizzo)
    {
        boolean esito;

        // Genero una istanza di GestoreUtenti.
        GestoreUtenti gestoreUtenti = new GestoreUtenti();

        // Genero una istanza di GestoreOrdini.
        GestoreOrdini gestoreOrdini = new GestoreOrdini();

        // Ottengo l'oggetto Carrello dell'utente attualmente loggato, in cui sono presenti i piatti da ordinare.
        Carrello carrello = gestoreUtenti.ricercaUtentePerId(idUtenteLoggato).getCarrello();

        // Ottengo la lista dei piatti presenti nel Carrello.
        List<Piatto> piatti = carrello.getPiatti();

        // Creo l'oggetto Ordine associato al nuovo ordine, e se questo viene creato con successo, ritorna "true".
        esito = gestoreOrdini.creaOrdine(piatti, indirizzo);

        return esito;
    }

    // Restituisce alla GUI (Boundary) gli ordini in entrata di un ristorante.
    // Fa parte del caso d'uso "Gestione Ordini Ricevuti".
    public static List<String[]> ottieniOrdiniRicevuti(int idRistorante)
    {
        // Genero una istanza di GestoreOrdini.
        GestoreOrdini gestoreOrdini = new GestoreOrdini();

        // GestoreOrdini restituisce la lista degli ordini in stato "Inviato" in base all'id del Ristorante.
        List<Ordine> ordiniInviati = gestoreOrdini.ricercaOrdiniInviatiPerRistorante(idRistorante);

        // La lista da restituire alla Boundary, ogni elemento è una riga della tabella nel DB.
        List<String[]> righe = new ArrayList<>();

        // Converto la lista di elementi Piatto in una lista di String, che verrà restituita alla Boundary.
        for (Ordine ordine : ordiniInviati) {

            String[] riga = new String[]{
                    String.valueOf(ordine.getId()),
                    ordine.getIndirizzoDiConsegna(),
                    // NOTA: Per ora, nella GUI l'utente ristoratore vedrà solo il numero di piatti.
                    String.valueOf(ordine.getListaPiatti().size())
            };

            righe.add(riga);
        }

        return righe;
    }

}

package entity;

public class GestoreUtenti {

    public Utente ricercaUtentePerUsername(String username)
    {
        return new Utente();
    }

    public Utente ricercaUtentePerId(int idUtente){
        return new Utente();
    }

}

package entity;

public class Ristorante {

    private int id;
    private int idProprietario;
    private String nome;
    private String descrizione;
    private String indirizzo;
    private Menu menu;

    public Ristorante(String nome,
                      String descrizione,
                      String indirizzo)
    {
        this.nome = nome;
        this.descrizione = descrizione;
        this.indirizzo = indirizzo;
    }

    public int getId(){
        return id;
    }

    public int getIdProprietario(){
        return idProprietario;
    }

    public String getNome(){
        return nome;
    }

    public String getDescrizione(){
        return descrizione;
    }

    public String getIndirizzo(){
        return indirizzo;
    }

    public Menu getMenu(){
        return menu;
    }

    public boolean aggiornaDatiRistorante(String nome,
                                          String descrizione,
                                          String indirizzo)
    {
        this.nome = nome;
        this.descrizione = descrizione;
        this.indirizzo = indirizzo;

        return true;
    }

}

package entity;

public class Piatto {

    private int id;
    private String nome;
    private String descrizione;
    private String prezzo;

    public int getId(){
        return id;
    }

    public String getNome(){
        return nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public String getPrezzo() {
        return prezzo;
    }
}

package entity;

import java.util.ArrayList;
import java.util.List;

public class Menu {

    private List<Piatto> piatti = new ArrayList<Piatto>();

    public List<Piatto> getListaPiatti(){
        return piatti;
    }

    public boolean aggiungiPiatto(String nome,
                                  String descrizione,
                                  float prezzo)
    {

        return false;

    }

    public int ricercaPiatto(int idRistorante,
                             int idPiatto)
    {
        return 1;
    }

    public boolean aggiornaDatiPiatto(int idPiatto,
                                   String nome,
                                   String descrizione,
                                   float prezzo)
    {
        return false;
    }

    public boolean rimuoviPiatto(int idPiatto)
    {
        return false;
    }
}

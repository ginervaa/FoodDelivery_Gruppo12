package entity;

import java.util.ArrayList;
import java.util.List;

public class GestoreRistoranti {

    public Ristorante ricercaRistorantePerId(int idRistorante)
    {
        return new Ristorante("Pizzeria GPE", "Pizzeria egiziana","Via Cheope, 33");
    }

    public List<Ristorante> ricercaRistorantiPerProprietario(int idProprietario)
    {
        List<Ristorante> lista = new ArrayList<>() {};
        lista.add(new Ristorante("Pizzeria GPE", "Pizzeria egiziana","Via Cheope, 33"));
        lista.add(new Ristorante("La Galleria","Ristorante di Carl Crack","Via Tossico, 12"));
        return lista;
    }

    public boolean creaRistorante(int idProprietario,
                                  String nome,
                                  String descrizione,
                                  String indirizzo)
    {
        return true;
    }
}

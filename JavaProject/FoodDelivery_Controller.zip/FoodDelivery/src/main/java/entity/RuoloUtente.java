package entity;

public enum RuoloUtente {
    CLIENTE,
    RISTORATORE,
    AMMINISTRATORE
}

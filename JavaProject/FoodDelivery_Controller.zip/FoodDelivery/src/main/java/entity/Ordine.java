package entity;

import java.util.List;

public class Ordine {

    private int id;
    private String indirizzoDiConsegna;
    private List<Piatto> listaPiatti;

    public int getId(){
        return id;
    }

    public String getIndirizzoDiConsegna(){
        return indirizzoDiConsegna;
    }

    public List<Piatto> getListaPiatti(){
        return listaPiatti;
    }

}

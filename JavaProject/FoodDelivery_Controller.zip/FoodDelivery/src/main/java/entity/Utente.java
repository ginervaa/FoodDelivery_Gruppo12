package entity;

public class Utente {

    Carrello carrello;
    RuoloUtente ruolo;

    public boolean verificaCredenziali(String username,
                                       String password,
                                       RuoloUtente ruolo)
    {
        return true;
    }

    public int getId()
    {
        return 1;
    }

    public Carrello getCarrello(){
        return carrello;
    }
}

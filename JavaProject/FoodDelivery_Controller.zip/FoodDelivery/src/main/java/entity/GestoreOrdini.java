package entity;

import java.util.ArrayList;
import java.util.List;

public class GestoreOrdini {

    private List<Ordine> ordini = new ArrayList<Ordine>();

    public List<Ordine> ricercaOrdiniInviatiPerRistorante(int idRistorante) {
    }

    public boolean creaOrdine(List<Piatto> listaPiatti,
                              String indirizzoConsegna)
    {
        return true;
    }

}

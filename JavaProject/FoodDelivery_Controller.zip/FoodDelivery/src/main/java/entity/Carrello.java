package entity;

import java.util.ArrayList;
import java.util.List;

public class Carrello {

    private List<Piatto> piatti = new ArrayList<>();

    public List<Piatto> getPiatti(){
        return piatti;
    }

    public boolean aggiungiPiatto(int idPiatto)
    {
        return true;
    }

}

// file: controller/ControllerDelivery.java
package controller;

import database.GestoreOrdini;
import database.GestoreRistoranti;
import database.GestoreUtenti;
import entity.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Controller unico del sistema Food Delivery.
 *
 * Segue il pattern GRASP Controller (Facade Controller):
 * è il punto di ingresso unico dalla Boundary verso il dominio.
 *
 * Tutti i metodi sono statici per semplicità, come da convenzione
 * adottata nel progetto.
 *
 * La gestione della sessione avviene tramite la variabile
 * idUtenteLoggato: una soluzione semplificata adatta
 * a un progetto universitario monoutente.
 */
public class ControllerDelivery {

    /** ID dell'utente attualmente autenticato. 0 = nessuno loggato. */
    private static long idUtenteLoggato = 0;

    // =========================================================
    // CASO D'USO: Accesso Utente
    // =========================================================

    /**
     * Realizza il caso d'uso "Accesso Utente".
     * Verifica le credenziali e imposta la sessione.
     *
     * @param username username inserito
     * @param password password inserita
     * @return true se le credenziali sono valide
     */
    public static boolean login(String username, String password) {
        GestoreUtenti gestoreUtenti = new GestoreUtenti();
        Utente utente = gestoreUtenti.ricercaUtente(username);

        if (utente == null) return false;

        boolean esito = utente.verificaCredenziali(username, password);
        if (esito) {
            idUtenteLoggato = utente.getId();
        }
        return esito;
    }

    // =========================================================
    // CASO D'USO: Gestione Profilo Ristorante
    // =========================================================

    /**
     * Restituisce alla Boundary la lista dei ristoranti dell'utente loggato.
     * Ogni String[] contiene: [id, nome, descrizione, indirizzo].
     */
    public static List<String[]> ottieniRistoranti() {
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        List<Ristorante> ristoranti =
                gestoreRistoranti.ricercaRistorantiPerProprietario(idUtenteLoggato);

        List<String[]> righe = new ArrayList<>();
        for (Ristorante r : ristoranti) {
            righe.add(new String[]{
                    String.valueOf(r.getId()),
                    r.getNome(),
                    r.getDescrizione(),
                    r.getIndirizzo()
            });
        }
        return righe;
    }

    /**
     * Realizza il caso d'uso "Creazione Profilo Ristorante".
     */
    public static boolean creaProfiloRistorante(String nome,
                                                String descrizione,
                                                String indirizzo) {
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        return gestoreRistoranti.creaRistorante(idUtenteLoggato, nome, descrizione, indirizzo);
    }

    /**
     * Realizza il caso d'uso "Modifica Profilo Ristorante".
     */
    public static boolean aggiornaProfiloRistorante(long idRistorante,
                                                    String nome,
                                                    String descrizione,
                                                    String indirizzo) {
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        Ristorante ristorante = gestoreRistoranti.ricercaRistorante(idRistorante);
        if (ristorante == null) return false;

        try {
            ristorante.aggiornaDatiRistorante(nome, indirizzo, descrizione);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // =========================================================
    // CASO D'USO: Gestione Menù
    // =========================================================

    /**
     * Restituisce la lista dei piatti di un ristorante.
     * Ogni String[] contiene: [id, nome, descrizione, prezzo].
     */
    public static List<String[]> ottieniPiatti(long idRistorante) {
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        Ristorante ristorante = gestoreRistoranti.ricercaRistorante(idRistorante);
        if (ristorante == null) return new ArrayList<>();

        List<String[]> righe = new ArrayList<>();
        for (Piatto p : ristorante.getMenu().getPiatti()) {
            righe.add(new String[]{
                    String.valueOf(p.getId()),
                    p.getNome(),
                    p.getDescrizione(),
                    String.format("%.2f", p.getPrezzo())
            });
        }
        return righe;
    }

    /** Realizza il caso d'uso "Gestione Menu - Inserimento Piatto". */
    public static boolean inserisciPiattoMenu(long idRistorante,
                                              String nome,
                                              String descrizione,
                                              double prezzo) {
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        Ristorante ristorante = gestoreRistoranti.ricercaRistorante(idRistorante);
        if (ristorante == null) return false;

        try {
            Piatto nuovoPiatto = new Piatto(nome, descrizione, prezzo);
            ristorante.getMenu().aggiungiPiatto(nuovoPiatto);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /** Realizza il caso d'uso "Gestione Menu - Modifica Piatto". */
    public static boolean modificaPiattoMenu(long idRistorante,
                                             String nomePiatto,
                                             String nuovoNome,
                                             String nuovaDescrizione,
                                             double nuovoPrezzo) {
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        Ristorante ristorante = gestoreRistoranti.ricercaRistorante(idRistorante);
        if (ristorante == null) return false;

        Piatto piatto = ristorante.getMenu().ricercaPiatto(nomePiatto);
        if (piatto == null) return false;

        try {
            ristorante.getMenu().aggiornaDatiPiatto(piatto, nuovoNome, nuovaDescrizione, nuovoPrezzo);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Realizza il caso d'uso "Gestione Menu - Rimozione Piatto". */
    public static boolean eliminaPiattoMenu(long idRistorante, String nomePiatto) {
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        Ristorante ristorante = gestoreRistoranti.ricercaRistorante(idRistorante);
        if (ristorante == null) return false;

        Piatto piatto = ristorante.getMenu().ricercaPiatto(nomePiatto);
        if (piatto == null) return false;

        try {
            ristorante.getMenu().rimuoviPiatto(piatto);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // =========================================================
    // CASO D'USO: Effettua Ordine
    // =========================================================

    /** Aggiunge un piatto al carrello dell'utente loggato. */
    public static boolean aggiungiPiattoCarrello(long idPiatto) {
        GestoreUtenti gestoreUtenti = new GestoreUtenti();
        Utente utente = gestoreUtenti.ricercaUtentePerId(idUtenteLoggato);
        if (utente == null || !(utente instanceof Cliente)) return false;

        Cliente cliente = (Cliente) utente;
        Carrello carrello = cliente.getCarrello();
        if (carrello == null) return false;

        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        Piatto piatto = gestoreRistoranti.ricercaPiatto(idPiatto);
        if (piatto == null) return false;

        try {
            carrello.aggiungiPiatto(piatto);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /** Invia l'ordine dal carrello dell'utente loggato. */
    public static boolean ordina(String indirizzoConsegna, long idRistorante) {
        GestoreUtenti gestoreUtenti = new GestoreUtenti();
        Utente utente = gestoreUtenti.ricercaUtentePerId(idUtenteLoggato);
        if (utente == null || !(utente instanceof Cliente)) return false;

        Cliente cliente = (Cliente) utente;
        Carrello carrello = cliente.getCarrello();
        if (carrello == null || carrello.isEmpty()) return false;

        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        Ristorante ristorante = gestoreRistoranti.ricercaRistorante(idRistorante);
        if (ristorante == null) return false;

        GestoreOrdini gestoreOrdini = new GestoreOrdini();
        boolean esito = gestoreOrdini.creaOrdine(
                indirizzoConsegna, cliente, ristorante, carrello.getPiatti());

        if (esito) {
            carrello.svuotaCarrello();
        }
        return esito;
    }

    // =========================================================
    // CASO D'USO: Gestione Ordini Ricevuti
    // =========================================================

    /**
     * Restituisce gli ordini in stato INVIATO per un ristorante.
     * Ogni String[] contiene: [id, indirizzoConsegna, numeroPiatti].
     */
    public static List<String[]> ottieniOrdiniRicevuti(long idRistorante) {
        GestoreOrdini gestoreOrdini = new GestoreOrdini();
        List<Ordine> ordini = gestoreOrdini.getOrdiniInviati(idRistorante);

        List<String[]> righe = new ArrayList<>();
        for (Ordine o : ordini) {
            righe.add(new String[]{
                    String.valueOf(o.getId()),
                    o.getIndirizzoConsegna(),
                    String.valueOf(o.getPiatti().size())
            });
        }
        return righe;
    }

    /** Realizza "accetta ordine" nel caso d'uso Gestione Ordini Ricevuti. */
    public static boolean accettaOrdine(long idOrdine) {
        GestoreOrdini gestoreOrdini = new GestoreOrdini();
        Ordine ordine = gestoreOrdini.ricercaOrdine(idOrdine);
        if (ordine == null) return false;

        try {
            ordine.accettaOrdine();
            return true;
        } catch (IllegalStateException e) {
            return false;
        }
    }

    /** Realizza "rifiuta ordine" nel caso d'uso Gestione Ordini Ricevuti. */
    public static boolean rifiutaOrdine(long idOrdine) {
        GestoreOrdini gestoreOrdini = new GestoreOrdini();
        Ordine ordine = gestoreOrdini.ricercaOrdine(idOrdine);
        if (ordine == null) return false;

        try {
            ordine.rifiutaOrdine();
            return true;
        } catch (IllegalStateException e) {
            return false;
        }
    }

    // =========================================================
    // CASO D'USO: Monitoraggio Attività Piattaforma
    // =========================================================

    /**
     * Realizza lo scenario "Visualizza ordini in un intervallo di tempo".
     *
     * Il GestoreOrdini è l'Information Expert: conosce tutti gli ordini
     * e sa come filtrarli per data.
     *
     * param dataInizioStr data inizio nel formato "YYYY-MM-DD"
     * param dataFineStr   data fine nel formato "YYYY-MM-DD"
     * return numero totale di ordini nell'intervallo, -1 in caso di errore
     */
    public static long visualizzaOrdiniTotali(String dataInizioStr, String dataFineStr) {
        if (dataInizioStr == null || dataInizioStr.isBlank()) return -1;
        if (dataFineStr   == null || dataFineStr.isBlank())   return -1;

        GestoreOrdini gestoreOrdini = new GestoreOrdini();
        return gestoreOrdini.getNumeroOrdini(dataInizioStr, dataFineStr);
    }

    /**
     * Realizza lo scenario "Visualizza ristoranti più attivi".
     *
     * Il GestoreRistoranti è l'Information Expert: conosce tutti i
     * ristoranti e sa come ordinarli per volume di ordini.
     *
     * return lista di String[] con [id, nome, numeroOrdini], ordinata per attività
     */
    public static List<String[]> visualizzaRistorantiPiuAttivi() {
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        List<Ristorante> ristoranti = gestoreRistoranti.ristorantiPiuAttivi();

        List<String[]> righe = new ArrayList<>();
        for (Ristorante r : ristoranti) {
            righe.add(new String[]{
                    String.valueOf(r.getId()),
                    r.getNome(),
                    String.valueOf(r.getNumeroOrdini())
            });
        }
        return righe;
    }

    /**
     * Realizza lo scenario "Visualizza volume medio degli ordini".
     *
     * Il GestoreOrdini è l'Information Expert: conosce tutti gli ordini
     * e sa calcolare la media dei piatti per ordine.
     *
     * @return stringa con il valore medio formattato (es. "3.50"), o "N/D" se errore
     */
    public static String visualizzaVolumeMedioOrdini() {
        GestoreOrdini gestoreOrdini = new GestoreOrdini();
        double media = gestoreOrdini.volumeMedioOrdini();
        if (media < 0) return "N/D";
        return String.format("%.2f", media);
    }
}
package entity;

import jakarta.persistence.*;

import java.util.Objects;

/**
 * Classe base che rappresenta tutti gli utenti del sistema.
 *
 * STRATEGIA: le sottoclassi sono tabelle distinte e separate.
 */

/**
 * @MappedSuperclass definisce un template.
 * Nessuna tabella "Utente" verrà generata nel database.
 * Gli attributi diventeranno colonne fisiche nelle tabelle figlie.
 */
@Entity
@Table(
        name = "utente",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = "username", name = "uq_utente_username"),
                @UniqueConstraint(columnNames = "email",    name = "uq_utente_email")
        }
)
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo_ruolo", discriminatorType = DiscriminatorType.STRING, length = 20)
public abstract class Utente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String username;

    @Column(nullable = false, length = 255)
    private String password;

    @Column(nullable = false, length = 50)
    private String nome;

    @Column(nullable = false, length = 50)
    private String cognome;

    @Column(nullable = false, length = 100)
    private String email;

    @Column(nullable = false, length = 200)
    private String indirizzo;

    /**
     * Costruttore no-arg richiesto da Hibernate per la reflection.
     * Protected: non deve essere usato dall'applicazione.
     */
    protected Utente() {}

    /**
     * Costruttore principale con validazione difensiva.
     * Garantisce che un Utente non possa mai essere creato in stato inconsistente.
     */
    public Utente(String username, String password, String nome,
                  String cognome, String email, String indirizzo) {

        if (username == null || username.isBlank())
            throw new IllegalArgumentException("Username obbligatorio e non può essere vuoto.");
        if (password == null || password.isBlank())
            throw new IllegalArgumentException("Password obbligatoria e non può essere vuota.");
        if (nome == null || nome.isBlank())
            throw new IllegalArgumentException("Nome obbligatorio.");
        if (cognome == null || cognome.isBlank())
            throw new IllegalArgumentException("Cognome obbligatorio.");
        if (email == null || email.isBlank())
            throw new IllegalArgumentException("Email obbligatoria.");
        if (!email.contains("@"))
            throw new IllegalArgumentException("Formato email non valido.");
        if (indirizzo == null || indirizzo.isBlank())
            throw new IllegalArgumentException("Indirizzo obbligatorio.");

        this.username  = username.trim();
        this.password  = password;
        this.nome      = nome.trim();
        this.cognome   = cognome.trim();
        this.email     = email.trim().toLowerCase();
        this.indirizzo = indirizzo.trim();
    }

    /**
     * Verifica le credenziali dell'utente.
     * NullPointerException-safe: gestisce input null esplicitamente.
     * Il confronto della password avviene sulla stringa memorizzata.
     * Se in futuro si usa BCrypt, questo metodo andrà sovrascritto nel
     * layer di sicurezza con BCrypt.checkpw(inputPassword, this.password).
     *
     * inputUsername username fornito al login
     * inputPassword password fornita al login
     * return true se corrispondono
     */
    public boolean verificaCredenziali(String inputUsername, String inputPassword) {
        if (inputUsername == null || inputPassword == null) return false;
        return this.username.equals(inputUsername) && this.password.equals(inputPassword);
    }

    // --- Getter ---

    public Long getId() { return id; }

    public String getUsername() { return username; }

    public String getPassword() { return password; }

    public String getNome() { return nome; }

    public String getCognome() { return cognome; }

    public String getEmail() { return email; }

    public String getIndirizzo() { return indirizzo; }

    // --- Setter (solo per aggiornamenti espliciti, con validazione) ---

    public void setUsername(String username) {
        if (username == null || username.isBlank())
            throw new IllegalArgumentException("Username non può essere vuoto.");
        this.username = username.trim();
    }

    public void setPassword(String password) {
        if (password == null || password.isBlank())
            throw new IllegalArgumentException("Password non può essere vuota.");
        this.password = password;
    }

    public void setNome(String nome) {
        if (nome == null || nome.isBlank())
            throw new IllegalArgumentException("Nome obbligatorio.");
        this.nome = nome;
    }

    public void setCognome(String cognome) {
        if (cognome == null || cognome.isBlank())
            throw new IllegalArgumentException("Cognome obbligatorio.");
        this.cognome = cognome;
    }

    public void setEmail(String email) {
        if (email == null || email.isBlank())
            throw new IllegalArgumentException("Email obbligatoria.");
        if (!email.contains("@"))
            throw new IllegalArgumentException("Formato email non valido.");
        this.email = email;
    }

    public void setIndirizzo(String indirizzo) {
        if (indirizzo == null || indirizzo.isBlank())
            throw new IllegalArgumentException("Indirizzo obbligatorio.");
        this.indirizzo = indirizzo;
    }

    /**
     * equals e hashCode basati sull'id persistente.
     * Questo è il pattern corretto per le JPA entity: due oggetti con lo stesso
     * id rappresentano la stessa riga del database, indipendentemente
     * dall'istanza Java. Se l'id è null (entità non ancora persistita),
     * si ricade sull'identità di riferimento (comportamento di default).
     *
     * Perché Hibernate può caricare la stessa riga come due oggetti diversi,
     * e equals basato sull'id garantisce la correttezza dei confronti.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Utente)) return false;
        Utente other = (Utente) o;
        // Due entità non persistite (id == null) non sono mai uguali tra loro
        return id != null && id.equals(other.id);
    }

    @Override
    public int hashCode() {
        // Costante fissa per entità non persistite: garantisce stabilità
        // nelle collection anche prima del flush su DB.
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() +
                "{id=" + id +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' + '}';
    }
}
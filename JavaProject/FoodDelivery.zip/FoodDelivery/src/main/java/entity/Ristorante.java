package entity;

import jakarta.persistence.*;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Rappresenta un Ristorante della piattaforma.
 *
 * COMPOSIZIONI:
 *   Ristorante ◆──── Menu            (1:1, composizione)
 *   Ristorante ◆──── OrarioApertura  (1:N, composizione)
 *
 * ASSOCIAZIONI:
 *   Ristoratore ──── Ristorante  (1:N, il Ristorante conosce il suo proprietario)
 *   Ristorante  ──── Ordine      (1:N, il Ristorante conosce gli ordini ricevuti)
 *
 * NOTA SU ordiniRicevuti:
 * Con mappedBy = "ristorante", Hibernate usa
 * la FK ristorante_id già presente nella tabella "ordine".
 *
 * NOTA SUL MENU:
 * Il Ristorante possiede la FK (menu_id nella tabella ristorante).
 * È lui il lato proprietario della relazione 1:1 con Menu.
 * Il Menu nasce nel costruttore del Ristorante (composizione reale).
 */

@Entity
@Table(name = "ristorante")
public class Ristorante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nome;

    @Column(nullable = false, length = 200)
    private String indirizzo;

    @Column(length = 500)
    private String descrizione;

    /**
     * Lato "molti" della relazione 1:N con Ristoratore.
     * Questa tabella contiene la FK proprietario_id.
     * nullable = false: un Ristorante deve sempre avere un proprietario.
     */
    @ManyToOne(optional = false)
    @JoinColumn(name = "proprietario_id", nullable = false)
    private Ristoratore proprietario;

    /**
     * Composizione 1:1 con Menu. Questo è il lato PROPRIETARIO.
     * La FK menu_id risiede nella tabella "ristorante".
     * CascadeType.ALL + orphanRemoval = true: il Menu muore con il Ristorante.
     */
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "menu_id", nullable = false)
    private Menu menu;

    /**
     * Composizione 1:N con OrarioApertura.
     * mappedBy = "ristorante": la FK è in orario_apertura.ristorante_id.
     * orphanRemoval = true: un orario non ha senso senza il suo ristorante.
     */
    @OneToMany(mappedBy = "ristorante", cascade = CascadeType.ALL,
            orphanRemoval = true, fetch = FetchType.LAZY)
    private List<OrarioApertura> orariApertura = new ArrayList<>();

    /**
     * Associazione 1:N con Ordine (gli ordini ricevuti dal ristorante).
     * mappedBy = "ristorante": la FK è in ordine.ristorante_id.
     * Nessun CascadeType: gli Ordini non vengono eliminati se si elimina un Ristorante
     * (hanno rilevanza storica per il Cliente).
     */
    @OneToMany(mappedBy = "ristorante", fetch = FetchType.LAZY)
    private List<Ordine> ordiniRicevuti = new ArrayList<>();

    /** Costruttore no-arg per Hibernate. */
    protected Ristorante() {}

    /**
     * Costruttore principale con validazione e inizializzazione del Menu.
     * Implementa la composizione: il Menu nasce con il Ristorante.
     */
    public Ristorante(String nome, String indirizzo, String descrizione) {
        if (nome == null || nome.isBlank())
            throw new IllegalArgumentException("Il nome del ristorante è obbligatorio.");
        if (indirizzo == null || indirizzo.isBlank())
            throw new IllegalArgumentException("L'indirizzo del ristorante è obbligatorio.");

        this.nome        = nome.trim();
        this.indirizzo   = indirizzo.trim();
        this.descrizione = descrizione;

        // COMPOSIZIONE: il Menu nasce con il Ristorante, non esiste prima.
        this.menu = new Menu();
        this.menu.setRistorante(this); // sincronizzazione bidirezionale in memoria
    }

    // --- Operazioni del Domain Model ---

    /**
     * Aggiorna i dati del ristorante.
     * Corrisponde a aggiornaDatiRistorante() del Domain Model.
     */
    public void aggiornaDatiRistorante(String nome, String indirizzo, String descrizione) {
        if (nome == null || nome.isBlank())
            throw new IllegalArgumentException("Il nome non può essere vuoto.");
        if (indirizzo == null || indirizzo.isBlank())
            throw new IllegalArgumentException("L'indirizzo non può essere vuoto.");

        this.nome        = nome.trim();
        this.indirizzo   = indirizzo.trim();
        this.descrizione = descrizione;
    }

    /**
     * Restituisce una rappresentazione testuale dei dati del ristorante.
     * Corrisponde a getDatiRistorante() del Domain Model.
     */
    public String getDatiRistorante() {
        return "Ristorante{nome='" + nome + "', indirizzo='" + indirizzo +
                "', descrizione='" + descrizione + "'}";
    }

    /**
     * Punto di accesso al Menu del Ristorante.
     * Corrisponde a getMenu() del Domain Model.
     * Questa è l'unica responsabilità che Ristorante ha verso Menu.
     * Tutte le operazioni sui Piatti passano da Menu direttamente.
     */
    public Menu getMenu() { return menu; }

    /**
     * Verifica se il ristorante è aperto nel momento specificato.
     * Corrisponde a isAperto() del Domain Model.
     * Usa DayOfWeek (type-safe) invece di String grezzo.
     *
     * param giorno giorno della settimana corrente
     * param ora    ora corrente
     * return true se il ristorante ha un orario che copre quel momento
     */
    public boolean isAperto(DayOfWeek giorno, LocalTime ora) {
        if (giorno == null || ora == null) return false;
        for (OrarioApertura o : orariApertura) {
            if (o.copreTempo(giorno, ora)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Restituisce il numero di ordini ricevuti.
     * Corrisponde a getNumeroOrdini() del Domain Model.
     */
    public int getNumeroOrdini() {
        return ordiniRicevuti.size();
    }

    /**
     * Calcola il volume medio degli ordini in termini di numero di piatti.
     * Corrisponde a volumeMedioOrdini() del Domain Model.
     * Restituisce 0.0 se non ci sono ordini (evita divisione per zero).
     */
    public double volumeMedioOrdini() {
        if (ordiniRicevuti.isEmpty()) return 0.0;
        int totalePiatti = 0;
        for (Ordine o : ordiniRicevuti) {
            totalePiatti += o.getPiatti().size();
        }
        return (double) totalePiatti / ordiniRicevuti.size();
    }

    /**
     * Aggiunge un OrarioApertura con sincronizzazione bidirezionale.
     * Impedisce duplicati sullo stesso giorno.
     *
     * throws IllegalArgumentException se orario è null o il giorno è già presente
     */
    public void aggiungiOrario(OrarioApertura orario) {
        if (orario == null)
            throw new IllegalArgumentException("L'orario non può essere null.");
        for (OrarioApertura o : orariApertura) {
            if (o.getGiornoSettimana() == orario.getGiornoSettimana()) {
                throw new IllegalArgumentException(
                        "Esiste già un orario per il giorno " + orario.getGiornoSettimana());
            }
        }
        orariApertura.add(orario);
        orario.setRistorante(this);
    }

    /**
     * Rimuove un OrarioApertura.
     * orphanRemoval su Hibernate cancellerà la riga dal DB al flush.
     */
    public void rimuoviOrario(OrarioApertura orario) {
        if (orario == null) return;
        if (orariApertura.remove(orario)) {
            orario.setRistorante(null);
        }
    }

    // --- Getter e Setter ---

    public Long getId()          { return id; }
    public String getNome()      { return nome; }
    public String getIndirizzo() { return indirizzo; }
    public String getDescrizione() { return descrizione; }

    public void setNome(String nome)               { this.nome = nome; }
    public void setIndirizzo(String indirizzo)     { this.indirizzo = indirizzo; }
    public void setDescrizione(String descrizione) { this.descrizione = descrizione; }

    public Ristoratore getProprietario() { return proprietario; }

    /** Package-private: impostato da Ristoratore.aggiungiRistorante() */
    void setProprietario(Ristoratore proprietario) { this.proprietario = proprietario; }

    /** Vista non modificabile degli orari: non esponiamo la lista interna. */
    public List<OrarioApertura> getOrariApertura() {
        return Collections.unmodifiableList(orariApertura);
    }

    /** Vista non modificabile degli ordini ricevuti. */
    public List<Ordine> getOrdiniRicevuti() {
        return Collections.unmodifiableList(ordiniRicevuti);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Ristorante)) return false;
        Ristorante other = (Ristorante) o;
        return id != null && id.equals(other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Ristorante{id=" + id + ", nome='" + nome + "'}";
    }
}
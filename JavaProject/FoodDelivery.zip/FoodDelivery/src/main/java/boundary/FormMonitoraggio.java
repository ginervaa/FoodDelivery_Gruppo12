// file: boundary/FormMonitoraggio.java
package boundary;

import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;
import com.intellij.uiDesigner.core.Spacer;
import controller.ControllerDelivery;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * Boundary per il caso d'uso "Monitoraggio Attività Piattaforma".
 * Accessibile solo dall'Amministratore dopo il login.
 *
 * - i componenti vengono dichiarati come campi privati
 *   (collegati al file .form di IntelliJ Swing UI Designer);
 * - il costruttore collega i listener ai pulsanti;
 * - un metodo apri() crea e mostra il JFrame.
 *
 * La Boundary non contiene logica di business:
 * legge input dalla GUI, chiama il Controller, mostra i risultati.
 */
public class FormMonitoraggio {

    // --- Componenti collegati al file .form tramite IntelliJ UI Designer ---
    private JPanel monitoraggioPanel;
    private JTextField txtDataInizio;
    private JTextField txtDataFine;
    private JButton btnCercaOrdini;
    private JLabel lblRisultatoOrdini;
    private JTable tabellaRistoranti;
    private JButton btnAggiornaRistoranti;
    private JLabel lblVolumeMedio;
    private JButton btnCalcolaVolume;

    /**
     * Costruttore: collega i listener ai pulsanti.
     * I componenti sono già stati creati dal file .form di IntelliJ.
     */
    public FormMonitoraggio() {

        // --- Listener: Cerca ordini in un intervallo di tempo ---
        btnCercaOrdini.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cercaOrdiniPerIntervallo();
            }
        });

        // --- Listener: Aggiorna tabella ristoranti più attivi ---
        btnAggiornaRistoranti.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                aggiornaRistorantiPiuAttivi();
            }
        });

        // --- Listener: Calcola volume medio ---
        btnCalcolaVolume.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calcolaVolumeMedio();
            }
        });
    }

    /**
     * Scenario "Visualizza ordini in un intervallo di tempo".
     *
     * La Boundary legge le due date, le valida superficialmente
     * (campo non vuoto), poi delega al Controller.
     * Il risultato viene mostrato nella label lblRisultatoOrdini.
     */
    private void cercaOrdiniPerIntervallo() {
        String dataInizio = txtDataInizio.getText().trim();
        String dataFine   = txtDataFine.getText().trim();

        // Validazione di formato: responsabilità della Boundary
        if (dataInizio.isEmpty() || dataFine.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Inserisci entrambe le date nel formato YYYY-MM-DD.",
                    "Campi mancanti",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // Delega al Controller: lui gestisce la logica applicativa
        long totale = ControllerDelivery.visualizzaOrdiniTotali(dataInizio, dataFine);

        if (totale == -1) {
            JOptionPane.showMessageDialog(
                    null,
                    "Date non valide. Usa il formato YYYY-MM-DD.",
                    "Errore",
                    JOptionPane.ERROR_MESSAGE
            );
            lblRisultatoOrdini.setText("—");
        } else {
            lblRisultatoOrdini.setText(String.valueOf(totale));
        }
    }

    /**
     * Scenario "Visualizza ristoranti più attivi".
     *
     * Chiama il Controller e popola la JTable con i risultati.
     * Ogni riga mostra: ID ristorante, nome, numero di ordini.
     */
    private void aggiornaRistorantiPiuAttivi() {
        List<String[]> righe = ControllerDelivery.visualizzaRistorantiPiuAttivi();

        String[] colonne = {"ID", "Nome Ristorante", "Numero Ordini"};
        DefaultTableModel model = new DefaultTableModel(colonne, 0);

        for (String[] riga : righe) {
            model.addRow(riga);
        }

        tabellaRistoranti.setModel(model);
    }

    /**
     * Scenario "Visualizza volume medio degli ordini".
     *
     * Chiama il Controller e mostra il risultato nella label.
     */
    private void calcolaVolumeMedio() {
        String media = ControllerDelivery.visualizzaVolumeMedioOrdini();
        lblVolumeMedio.setText(media + " piatti/ordine");
    }

    /**
     * Crea e mostra il JFrame per il monitoraggio.
     * Stessa struttura del metodo apri_form_caricamento() del professore.
     *
     * @return il JFrame creato, così chi lo apre può gestirlo (es. evitare duplicati)
     */
    public static JFrame apriFormMonitoraggio() {
        JFrame frame = new JFrame("Monitoraggio Attività Piattaforma");

        FormMonitoraggio form = new FormMonitoraggio();
        frame.setContentPane(form.monitoraggioPanel);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setResizable(false);

        return frame;
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        monitoraggioPanel = new JPanel();
        monitoraggioPanel.setLayout(new GridLayoutManager(6, 4, new Insets(0, 0, 0, 0), -1, -1));
        tabellaRistoranti = new JTable();
        monitoraggioPanel.add(tabellaRistoranti, new GridConstraints(3, 1, 1, 3, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_WANT_GROW, null, new Dimension(150, 50), null, 0, false));
        final Spacer spacer1 = new Spacer();
        monitoraggioPanel.add(spacer1, new GridConstraints(4, 1, 1, 3, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_VERTICAL, 1, GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        lblVolumeMedio = new JLabel();
        lblVolumeMedio.setText("Volume Medio");
        monitoraggioPanel.add(lblVolumeMedio, new GridConstraints(5, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnCalcolaVolume = new JButton();
        btnCalcolaVolume.setText("Calcola Volume");
        monitoraggioPanel.add(btnCalcolaVolume, new GridConstraints(5, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnAggiornaRistoranti = new JButton();
        btnAggiornaRistoranti.setText("Aggiorna Ristoranti");
        monitoraggioPanel.add(btnAggiornaRistoranti, new GridConstraints(3, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnCercaOrdini = new JButton();
        btnCercaOrdini.setText("Cerca Ordini");
        monitoraggioPanel.add(btnCercaOrdini, new GridConstraints(1, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        lblRisultatoOrdini = new JLabel();
        lblRisultatoOrdini.setText("Risultato Ordini");
        monitoraggioPanel.add(lblRisultatoOrdini, new GridConstraints(1, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final Spacer spacer2 = new Spacer();
        monitoraggioPanel.add(spacer2, new GridConstraints(2, 1, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_VERTICAL, 1, GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        txtDataInizio = new JTextField();
        txtDataInizio.setText("Data Inizio");
        monitoraggioPanel.add(txtDataInizio, new GridConstraints(0, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        txtDataFine = new JTextField();
        txtDataFine.setText("Data Fine");
        monitoraggioPanel.add(txtDataFine, new GridConstraints(0, 2, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return monitoraggioPanel;
    }
}
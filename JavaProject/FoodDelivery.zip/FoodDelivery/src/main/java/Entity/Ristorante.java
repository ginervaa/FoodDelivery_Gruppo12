package Entity;

import Database.GestorePersistenza;
import jakarta.persistence.*;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Entity // Specifica che sarà un'entità da tradurre in una tabella.
@Table(name = "Ristoranti") // Specifica il nome della tabella nel DB.
public class Ristorante {

    @Id // Indica che l'attributo sarà la chiave primaria.
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Delega la creazione automatica dell'id al DB.
    private Long id;

    @ManyToOne // Un ristorante può avere un unico proprietario.
    @JoinColumn(name = "proprietario_id") /* La FK associata al Ristoratore proprietario nella tabella "Ordini"
                                             si chiamerà "proprietario_id". */
    private Ristoratore proprietario;

    @Column(nullable = false) // Specifica che questa colonna sarà "NOT NULL" nel DB.
    private String nome;

    private String descrizione;

    @Column(nullable = false) // Specifica che questa colonna sarà "NOT NULL" nel DB.
    private String indirizzo;

    @OneToMany(mappedBy = "ristorante", fetch = FetchType.EAGER)
    /* Il ristorante possiede più orari di apertura, nella classe OrarioApertura
       il riferimento a Ristorante è denominato "ristorante".
       FetchType.EAGER indica che ogni volta che viene istanziato un Ristorante
       verranno automaticamente prelevati dal DB tutti i suoi OrarioApertura
       e aggiunti alla sua lista "orariApertura" */
    private List<OrarioApertura> orariApertura = new ArrayList<>();

    @OneToMany(mappedBy = "ristorante", fetch = FetchType.EAGER)
    /* Il ristorante possiede più piatti, nella classe Piatto il riferimento a
       Ristorante è denominato "ristorante".
       FetchType.EAGER indica che ogni volta che viene istanziato un Ristorante
       verranno automaticamente prelevati dal DB tutti i suoi Piatto
       e aggiunti alla sua lista "menu" */
    private List<Piatto> menu = new ArrayList<>();

    @OneToMany(mappedBy = "ristorante") /* Il ristorante possiede più ordini, nella classe Ordine il riferimento a
                                           Ristorante è denominato "ristorante". */
    private List<Ordine> ordini = new ArrayList<>();

    // Costruttore vuoto, serve a JPA.
    public Ristorante() {
    }

    // Costruttore di Ristorante.
    public Ristorante(String nome,
                      String descrizione,
                      String indirizzo,
                      Ristoratore proprietario)
    {
        this.nome = nome;
        this.descrizione = descrizione;
        this.indirizzo = indirizzo;
        this.proprietario = proprietario;
    }

    // Metodo getter dell'id.
    public Long getId(){
        return id;
    }

    // Metodo getter dell'oggetto Ristoratore proprietario.
    public Ristoratore getProprietario(){
        return proprietario;
    }

    // Metodo getter del nome del ristorante.
    public String getNome(){
        return nome;
    }

    public String getDescrizione(){
        return descrizione;
    }

    public String getIndirizzo(){
        return indirizzo;
    }

    // Metodo per aggiungere un orario di apertura al Ristorante.
    public boolean aggiungiOrarioApertura (DayOfWeek giornoSettimana,
                                                  LocalTime oraApertura,
                                                  LocalTime oraChiusura)
    {
        // Creo l'oggetto OrarioApertura e lo aggiungo alla lista degli orari.
        OrarioApertura orarioApertura = new OrarioApertura(giornoSettimana, oraApertura, oraChiusura, this);
        boolean aggiuntoAgliOrari = orariApertura.add(orarioApertura);

        /* Gestisco anche il salvataggio nel DB del nuovo oggetto OrarioApertura,
           poiché Ristorante è Information Expert e Creator di OrarioApertura */
        GestorePersistenza gestorePersistenza = new GestorePersistenza();
        boolean aggiuntoAlDB = gestorePersistenza.salva(orarioApertura);

        return aggiuntoAgliOrari && aggiuntoAlDB;
    }

    public boolean isAperto() {

        // La variabile momento indica l'orario attuale.
        LocalDateTime momento = LocalDateTime.now();

        // Nella variabile giornoOggi conservo il giorno attuale.
        DayOfWeek giornoOggi = momento.getDayOfWeek();

        // Nella variabile oraAttuale conservo l'orario attuale.
        LocalTime oraAttuale = momento.toLocalTime();

        /* Verifico per ogni orario di apertura del Ristorante, se l'orario attuale è compreso
           all'interno in uno dei suoi orari di apertura. */
        for (OrarioApertura o : orariApertura) {
            System.out.println(o.getGiornoSettimana());
            if (giornoOggi == o.getGiornoSettimana()){
                System.out.println(oraAttuale);
                System.out.println(o.getOraApertura() + " " + o.getOraChiusura());
                if (oraAttuale.isAfter(o.getOraApertura()) && oraAttuale.isBefore(o.getOraChiusura())){
                    System.out.println((this.id + " aperto"));
                    return true;
                }
            }
        }
        return false;
    }

    // Restituisce l'oggetto Piatto ricercato in base all'id.
    public Piatto ricercaPiattoPerId(Long idPiatto) {

        // Ciclo che scorre tutto il menù, e quando trova il piatto lo restituisce.
        /* NOTA: Se non avessi messo fetch = FetchType.EAGER nell'annotazione dell'attributo menu,
           avrei dovuto fare la ricerca nel DB usando il GestorePersistenza. */
        for (Piatto p : menu) {
            if (p.getId().equals(idPiatto)) {
                return p;
            }
        }

        // Se non trova nessun piatto con l'id desiderato, restituisce null.
        return null;

    }

    // Permettere di aggiungere un piatto al menù del Ristorante, restituisce l'oggetto Piatto creato.
    public boolean aggiungiPiatto(String nome,
                                  String descrizione,
                                  float prezzo)
    {
        // Creo l'oggetto Piatto e lo aggiungo al menù.
        Piatto piatto = new Piatto(nome, descrizione, prezzo, this);
        boolean aggiuntoAlMenu = menu.add(piatto);

        /* Gestisco anche il salvataggio nel DB del nuovo oggetto Piatto,
           poiché Ristorante è Information Expert e Creator di Piatto */
        GestorePersistenza gestorePersistenza = new GestorePersistenza();
        boolean aggiuntoAlDB = gestorePersistenza.salva(piatto);

        return aggiuntoAlMenu && aggiuntoAlDB;
    }

    // Restituisce il numero di ordini ricevuti.
    public int getNumeroOrdini() {
        return ordini.size();
    }

}

package entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Rappresenta un utente con ruolo Ristoratore.
 *
 * RELAZIONE CON RISTORANTE: 1:N bidirezionale.
 * Un Ristoratore può possedere più Ristoranti.
 * mappedBy = "proprietario": la FK proprietario_id è nella tabella "ristorante".
 * CascadeType.ALL: se si elimina un Ristoratore, si eliminano anche i suoi Ristoranti.
 * orphanRemoval = true: se un Ristorante viene rimosso dalla lista,
 * viene cancellato dal DB (non può esistere senza proprietario).
 *
 * FETCH LAZY (default per @OneToMany): i ristoranti vengono caricati
 * dal DB solo quando si chiama esplicitamente getRistoranti().
 */

@Entity
@DiscriminatorValue("RISTORATORE")
public class Ristoratore extends Utente {

    @OneToMany(mappedBy = "proprietario", cascade = CascadeType.ALL,
            orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Ristorante> ristoranti = new ArrayList<>();

    /** Costruttore no-arg per Hibernate. */
    protected Ristoratore() {}

    public Ristoratore(String username, String password, String nome,
                       String cognome, String email, String indirizzo) {
        super(username, password, nome, cognome, email, indirizzo);
    }

    /**
     * Aggiunge un Ristorante con sincronizzazione bidirezionale.
     * Questo è l'UNICO modo corretto per associare un Ristorante a un Ristoratore.
     * Garantisce che sia la lista che il back-reference siano aggiornati in memoria.
     *
     * @throws IllegalArgumentException se ristorante è null
     */
    public void aggiungiRistorante(Ristorante ristorante) {
        if (ristorante == null)
            throw new IllegalArgumentException("Il ristorante non può essere null.");
        if (!ristoranti.contains(ristorante)) {
            ristoranti.add(ristorante);
            ristorante.setProprietario(this); // sincronizzazione lato inverso
        }
    }

    /**
     * Rimuove un Ristorante con sincronizzazione bidirezionale.
     * orphanRemoval farà sì che Hibernate cancelli il Ristorante dal DB al flush.
     */
    public void rimuoviRistorante(Ristorante ristorante) {
        if (ristorante == null) return;
        if (ristoranti.remove(ristorante)) {
            ristorante.setProprietario(null); // sgancia il back-reference
        }
    }

    /** Vista non modificabile per evitare modifiche non controllate alla lista. */
    public List<Ristorante> getRistoranti() {
        return Collections.unmodifiableList(ristoranti);
    }
}
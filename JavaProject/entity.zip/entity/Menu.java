package entity;

import jakarta.persistence.*;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Rappresenta il Menu di un Ristorante, contenente la lista dei Piatti.
 *
 * COMPOSIZIONE:
 *   Ristorante ◆──── Menu (composizione, 1:1)
 *   Menu       ◆──── Piatto (composizione, 1:N)
 *
 * Il Menu nasce e muore con il Ristorante.
 * Un Piatto nasce e muore con il Menu.
 * CascadeType.ALL + orphanRemoval = true realizzano entrambe le composizioni.
 *
 * mappedBy = "menu": la FK non è qui, è nella tabella "piatto" (colonna menu_id).
 * Questo lato è il lato "inverso" (non proprietario) della relazione.
 */
@Entity
@Table(name = "menu")
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Lato inverso della relazione 1:1 con Ristorante.
     * La FK (menu_id) risiede nella tabella "ristorante".
     * mappedBy rimanda al campo "menu" di Ristorante.
     */
    @OneToOne(mappedBy = "menu")
    private Ristorante ristorante;

    /**
     * Composizione Menu → Piatto.
     * CascadeType.ALL: operazioni JPA sul Menu si propagano ai Piatti.
     * orphanRemoval: se un Piatto viene rimosso dalla lista, viene
     * automaticamente cancellato dal database (non può esistere senza Menu).
     */
    @OneToMany(mappedBy = "menu", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Piatto> piatti = new ArrayList<>();

    /** Costruttore no-arg per Hibernate. */
    protected Menu() {}

    // --- Operazioni del Domain Model ---

    /**
     * Aggiunge un Piatto al Menu sincronizzando il back-reference.
     * Corrisponde a aggiungiPiatto() del Domain Model.
     * Non permette duplicati (stesso oggetto per riferimento o stesso id).
     *
     * throws IllegalArgumentException se piatto è null
     */
    public void aggiungiPiatto(Piatto piatto) {
        if (piatto == null)
            throw new IllegalArgumentException("Il piatto non può essere null.");
        if (!piatti.contains(piatto)) {
            piatti.add(piatto);
            piatto.setMenu(this); // sincronizzazione bidirezionale
        }
    }

    /**
     * Rimuove un Piatto dal Menu.
     * Grazie a orphanRemoval, Hibernate cancellerà il Piatto dal DB al flush.
     * Corrisponde a rimuoviPiatto() del Domain Model.
     *
     * throws IllegalArgumentException se piatto è null
     * throws IllegalStateException se il piatto non appartiene a questo menu
     */
    public void rimuoviPiatto(Piatto piatto) {
        if (piatto == null)
            throw new IllegalArgumentException("Il piatto non può essere null.");
        if (!piatti.contains(piatto))
            throw new IllegalStateException("Il piatto non appartiene a questo menu.");
        piatti.remove(piatto);
        piatto.setMenu(null); // sgancia il back-reference in memoria
    }

    /**
     * Ricerca un Piatto per nome (case-insensitive).
     * Corrisponde a ricercaPiatto() del Domain Model.
     *
     * return il Piatto trovato, o null se non esiste
     */
    public Piatto ricercaPiatto(String nomePiatto) {
        if (nomePiatto == null || nomePiatto.isBlank()) return null;
        return piatti.stream()
                .filter(p -> p.getNome().equalsIgnoreCase(nomePiatto.trim()))
                .findFirst()
                .orElse(null);
    }

    /**
     * Aggiorna i dati di un Piatto già presente nel Menu.
     * Corrisponde a aggiornaDatiPiatto() del Domain Model.
     * La validazione del Piatto è delegata al metodo setDatiPiatto() di Piatto.
     *
     * throws IllegalArgumentException se piatto è null
     * throws IllegalStateException se il piatto non appartiene a questo menu
     */
    public void aggiornaDatiPiatto(Piatto piatto, String nuovoNome,
                                   String nuovaDescrizione, double nuovoPrezzo) {
        if (piatto == null)
            throw new IllegalArgumentException("Il piatto non può essere null.");
        if (!piatti.contains(piatto))
            throw new IllegalStateException("Il piatto non appartiene a questo menu.");
        piatto.setDatiPiatto(nuovoNome, nuovaDescrizione, nuovoPrezzo);
    }

    /**
     * Restituisce la lista dei piatti come vista non modificabile.
     * Corrisponde a getPiatti() del Domain Model.
     * Non esponiamo la lista interna per evitare modifiche non controllate
     * che bypasserebbero la sincronizzazione bidirezionale.
     */
    public List<Piatto> getPiatti() {
        return Collections.unmodifiableList(piatti);
    }

    // --- Getter e Setter (package-private dove necessario) ---

    public Long getId() { return id; }

    public Ristorante getRistorante() { return ristorante; }

    /** Package-private: solo Ristorante imposta questo back-reference. */
    void setRistorante(Ristorante ristorante) { this.ristorante = ristorante; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Menu)) return false;
        Menu other = (Menu) o;
        return id != null && id.equals(other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Menu{id=" + id + ", numeroPiatti=" + piatti.size() + '}';
    }
}
package entity;

import jakarta.persistence.*;

/**
 * Sottoclasse concreta di Utente che rappresenta un Amministratore della piattaforma.
 *
 * Non aggiunge attributi propri: la distinzione è puramente comportamentale.
 */

@Entity
@DiscriminatorValue("AMMINISTRATORE")
public class Amministratore extends Utente {

    /** Costruttore no-arg richiesto da Hibernate. */
    public Amministratore() {}

    public Amministratore(String username, String password, String nome, String cognome, String email, String indirizzo) {
        super(username, password, nome, cognome, email, indirizzo);
    }
}
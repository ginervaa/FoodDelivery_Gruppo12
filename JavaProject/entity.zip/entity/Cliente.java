package entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Rappresenta un utente con ruolo Cliente.
 *
 * RELAZIONE CON CARRELLO: 1:1 bidirezionale.
 * Cliente è il lato INVERSO: la FK risiede nella tabella "carrello".
 * mappedBy = "cliente" rimanda al campo "cliente" in Carrello.
 * CascadeType.ALL: il Carrello nasce e muore con il Cliente.
 * orphanRemoval = true: se il carrello viene scollegato, viene eliminato dal DB.
 *
 * CREAZIONE DEL CARRELLO:
 * Il Carrello viene creato nel costruttore del Cliente e associato subito.
 * Questo implementa correttamente la relazione 1:1 obbligatoria:
 * non può esistere un Cliente senza Carrello, né un Carrello senza Cliente.
 *
 * STORICO ORDINI:
 * La relazione StoricoOrdini del Domain Model è modellata come @OneToMany
 * verso Ordine con mappedBy = "cliente". Non è una composizione: gli ordini
 * hanno rilevanza storica e non devono essere eliminati se si elimina il Cliente.
 */

@Entity
@Table(
        name = "cliente",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = "username", name = "uq_cliente_username"),
                @UniqueConstraint(columnNames = "email",    name = "uq_cliente_email")
        }
)
public class Cliente extends Utente {

    /**
     * Lato inverso della relazione 1:1 con Carrello.
     * La FK è in carrello.cliente_id.
     * CascadeType.ALL: persistenza/eliminazione del Carrello cascata dal Cliente.
     * orphanRemoval: se setCarrello(null) viene chiamato, il Carrello viene eliminato dal DB.
     */
    @OneToOne(mappedBy = "cliente", cascade = CascadeType.ALL,
            orphanRemoval = true, fetch = FetchType.LAZY)
    private Carrello carrello;

    /**
     * Storico degli ordini effettuati dal Cliente.
     * mappedBy = "cliente": la FK è in ordine.cliente_id.
     * Nessun CascadeType: gli ordini non devono essere eliminati con il Cliente.
     * LAZY: lo storico viene caricato solo quando esplicitamente richiesto.
     */
    @OneToMany(mappedBy = "cliente", fetch = FetchType.LAZY)
    private List<Ordine> storicoOrdini = new ArrayList<>();

    /** Costruttore no-arg per Hibernate. */
    protected Cliente() {}

    /**
     * Costruttore principale.
     * Crea e associa automaticamente il Carrello al Cliente.
     * Implementa la relazione obbligatoria 1:1: nessun Cliente esiste senza Carrello.
     */
    public Cliente(String username, String password, String nome,
                   String cognome, String email, String indirizzo) {
        super(username, password, nome, cognome, email, indirizzo);

        // CREAZIONE AUTOMATICA DEL CARRELLO: composizione reale
        this.carrello = new Carrello(this);
    }

    // --- Getter ---

    public Carrello getCarrello() { return carrello; }

    /** Vista non modificabile dello storico ordini. */
    public List<Ordine> getStoricoOrdini() {
        return Collections.unmodifiableList(storicoOrdini);
    }
}
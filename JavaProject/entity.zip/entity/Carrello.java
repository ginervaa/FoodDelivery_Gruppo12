package entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Rappresenta il carrello virtuale di un Cliente.
 *
 * RELAZIONE CON CLIENTE: 1:1 bidirezionale.
 * Carrello è il lato PROPRIETARIO: possiede la FK cliente_id.
 * Il Cliente conosce il suo Carrello tramite mappedBy = "cliente".
 *
 * NOTA SUL CICLO DI VITA:
 * Il Carrello nasce quando viene creato il Cliente
 * (il costruttore di Cliente crea e associa il Carrello).
 * Non esiste un Carrello senza Cliente.
 *
 * NOTA SUI DUPLICATI IN aggiungiPiatto():
 * Il codice originale permetteva di aggiungere lo stesso Piatto più volte.
 * In un carrello reale si possono aggiungere quantità multiple dello stesso piatto,
 * ma nel nostro Domain Model non esiste una classe RigaCarrello con una quantità.
 * La scelta corretta per fedeltà al Domain Model è permettere duplicati
 * (ogni aggiunta è un'unità distinta), come avviene in tutti i delivery app reali.
 * Se in futuro si introduce una quantità, si aggiunge una classe associativa.
 */
@Entity
@Table(name = "carrello")
public class Carrello {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Lato proprietario della relazione 1:1 con Cliente.
     * La FK cliente_id risiede nella tabella "carrello".
     * nullable = false: un Carrello non può esistere senza Cliente.
     */
    @OneToOne(optional = false)
    @JoinColumn(name = "cliente_id", nullable = false, unique = true)
    private Cliente cliente;

    /**
     * Relazione ManyToMany con Piatto.
     * Tabella di giunzione "carrello_piatto" separata da "ordine_piatto".
     * Unidirezionale: Piatto non conosce i Carrelli che lo contengono.
     * Questo evita di inquinare la classe Piatto con liste di contesto transazionale.
     *
     * FETCH LAZY: i piatti vengono caricati solo quando necessario.
     */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "carrello_piatto",
            joinColumns        = @JoinColumn(name = "carrello_id"),
            inverseJoinColumns = @JoinColumn(name = "piatto_id")
    )
    private List<Piatto> piatti = new ArrayList<>();

    /** Costruttore no-arg per Hibernate. */
    protected Carrello() {}

    /**
     * Costruttore principale: il Carrello nasce sempre con il suo Cliente.
     * Imposta subito la FK cliente_id.
     *
     * throws IllegalArgumentException se cliente è null
     */
    public Carrello(Cliente cliente) {
        if (cliente == null)
            throw new IllegalArgumentException("Il cliente non può essere null.");
        this.cliente = cliente;
    }

    // --- Operazioni del Domain Model ---

    /**
     * Aggiunge un Piatto al Carrello.
     * Corrisponde a aggiungiPiatto() del Domain Model.
     * I duplicati sono permessi: ogni aggiunta rappresenta un'unità del piatto.
     *
     * throws IllegalArgumentException se piatto è null
     */
    public void aggiungiPiatto(Piatto piatto) {
        if (piatto == null)
            throw new IllegalArgumentException("Il piatto non può essere null.");
        piatti.add(piatto);
    }

    /**
     * Rimuove una sola occorrenza del Piatto dal Carrello.
     * Se il piatto è stato aggiunto più volte, rimuove solo la prima occorrenza.
     *
     * param piatto il piatto da rimuovere
     * return true se il piatto era presente ed è stato rimosso
     */
    public boolean rimuoviPiatto(Piatto piatto) {
        if (piatto == null) return false;
        return piatti.remove(piatto);
    }

    /**
     * Svuota completamente il Carrello.
     * Corrisponde a svuotaCarrello() del Domain Model.
     * Viene chiamato tipicamente dopo che l'ordine viene inviato.
     */
    public void svuotaCarrello() {
        piatti.clear();
    }

    /**
     * Calcola il totale del Carrello sommando i prezzi dei piatti.
     * Metodo di utilità non esplicito nel Domain Model ma necessario
     * per la conferma dell'ordine.
     */
    public double calcolaTotale() {
        return piatti.stream()
                .mapToDouble(Piatto::getPrezzo)
                .sum();
    }

    /**
     * Verifica se il carrello è vuoto.
     * Usato dal Controller prima di permettere l'invio dell'ordine.
     */
    public boolean isEmpty() {
        return piatti.isEmpty();
    }

    // --- Getter ---

    public Long getId()           { return id; }
    public Cliente getCliente()   { return cliente; }

    /** Vista non modificabile: le modifiche passano da aggiungiPiatto/rimuoviPiatto. */
    public List<Piatto> getPiatti() {
        return Collections.unmodifiableList(piatti);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Carrello)) return false;
        Carrello other = (Carrello) o;
        return id != null && id.equals(other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Carrello{id=" + id + ", numeroPiatti=" + piatti.size() + '}';
    }
}
package entity;

import jakarta.persistence.*;
import java.util.Objects;

/**
 * Rappresenta un singolo piatto presente nel Menu di un Ristorante.
 *
 * CICLO DI VITA: Piatto è in composizione con Menu.
 * Non esiste un Piatto senza un Menu. La FK menu_id è nullable = false.
 * La creazione e distruzione avvengono sempre tramite i metodi di Menu.
 *
 * NOTA SU equals/hashCode: Piatto partecipa a List<Piatto> sia in Carrello
 * che in Ordine. Senza equals/hashCode corretti, contains() userebbe
 * l'identità di riferimento Java, che fallisce dopo la detach di Hibernate.
 * Usiamo l'id persistente come criterio di uguaglianza.
 */
@Entity
@Table(name = "piatto")
public class Piatto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nome;

    @Column(length = 500)
    private String descrizione;

    @Column(nullable = false)
    private double prezzo;

    /**
     * Lato "molti" della composizione Menu → Piatto.
     * nullable = false: un Piatto non può esistere senza Menu.
     */
    @ManyToOne(optional = false)
    @JoinColumn(name = "menu_id", nullable = false)
    private Menu menu;

    /** Costruttore no-arg per Hibernate. */
    protected Piatto() {}

    /**
     * Costruttore con validazione difensiva.
     * Il menu viene impostato separatamente da Menu.aggiungiPiatto().
     */
    public Piatto(String nome, String descrizione, double prezzo) {
        if (nome == null || nome.isBlank())
            throw new IllegalArgumentException("Il nome del piatto è obbligatorio.");
        if (prezzo < 0)
            throw new IllegalArgumentException("Il prezzo non può essere negativo.");

        this.nome        = nome.trim();
        this.descrizione = descrizione;
        this.prezzo      = prezzo;
    }

    /**
     * Aggiorna tutti i dati del piatto in un'unica operazione atomica.
     * Corrisponde a setDatiPiatto() del Domain Model.
     * La validazione è difensiva: impedisce stati inconsistenti.
     */
    public void setDatiPiatto(String nome, String descrizione, double prezzo) {
        if (nome == null || nome.isBlank())
            throw new IllegalArgumentException("Il nome del piatto non può essere vuoto.");
        if (prezzo < 0)
            throw new IllegalArgumentException("Il prezzo non può essere negativo.");

        this.nome        = nome.trim();
        this.descrizione = descrizione;
        this.prezzo      = prezzo;
    }

    // --- Getter ---
    public Long getId()            { return id; }
    public String getNome()        { return nome; }
    public String getDescrizione() { return descrizione; }
    public double getPrezzo()      { return prezzo; }
    public Menu getMenu()          { return menu; }

    // --- Setter (solo per uso interno da Menu) ---
    /** Package-private: solo Menu può impostare il back-reference. */
    void setMenu(Menu menu) { this.menu = menu; }

    // Setter individuali per modifiche parziali (es. solo prezzo)
    public void setNome(String nome)               { this.nome = nome; }
    public void setDescrizione(String descrizione) { this.descrizione = descrizione; }
    public void setPrezzo(double prezzo) {
        if (prezzo < 0) throw new IllegalArgumentException("Prezzo non può essere negativo.");
        this.prezzo = prezzo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Piatto)) return false;
        Piatto other = (Piatto) o;
        return id != null && id.equals(other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Piatto{id=" + id + ", nome='" + nome + "', prezzo=" + prezzo + '}';
    }
}
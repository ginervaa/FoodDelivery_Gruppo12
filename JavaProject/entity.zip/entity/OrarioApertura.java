package entity;

import jakarta.persistence.*;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.Objects;

/**
 * Rappresenta l'orario di apertura di un Ristorante per un determinato giorno.
 *
 * CICLO DI VITA: in composizione con Ristorante.
 * Non può esistere senza un Ristorante (nullable = false sulla FK).
 *
 * USO DI DayOfWeek (java.time):
 * Hibernate 6.x supporta nativamente DayOfWeek come @Enumerated(EnumType.STRING).
 * Questo garantisce type-safety: è impossibile salvare un giorno invalido
 * come "Lunediii" o "lunedi" che una String grezza permetterebbe.
 * La colonna nel DB conterrà stringhe come "MONDAY", "TUESDAY", etc.
 *
 * USO DI LocalTime:
 * Hibernate 6.x mappa LocalTime su TIME nel database nativamente.
 * Nessuna conversione manuale necessaria.
 */
@Entity
@Table(
        name = "orario_apertura",
        // Vincolo di unicità: stesso ristorante non può avere due orari per lo stesso giorno
        uniqueConstraints = @UniqueConstraint(
                columnNames = {"ristorante_id", "giorno_settimana"},
                name = "uq_orario_ristorante_giorno"
        )
)
public class OrarioApertura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Giorno della settimana.
     * EnumType.STRING salva "MONDAY", "TUESDAY" etc. nel DB invece del
     * numero ordinale (0, 1...). STRING è preferibile: è leggibile e
     * non si rompe se si riordina l'enum.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "giorno_settimana", nullable = false, length = 15)
    private DayOfWeek giornoSettimana;

    @Column(name = "ora_apertura", nullable = false)
    private LocalTime oraApertura;

    @Column(name = "ora_chiusura", nullable = false)
    private LocalTime oraChiusura;

    /**
     * Lato "molti" della composizione Ristorante → OrarioApertura.
     * La FK ristorante_id è nella tabella orario_apertura (questo lato).
     * nullable = false: un orario non può esistere senza ristorante.
     */
    @ManyToOne(optional = false)
    @JoinColumn(name = "ristorante_id", nullable = false)
    private Ristorante ristorante;

    /** Costruttore no-arg per Hibernate. */
    protected OrarioApertura() {}

    /**
     * Costruttore con validazione difensiva.
     * Garantisce che oraApertura sia sempre prima di oraChiusura.
     */
    public OrarioApertura(DayOfWeek giornoSettimana,
                          LocalTime oraApertura,
                          LocalTime oraChiusura) {
        if (giornoSettimana == null)
            throw new IllegalArgumentException("Il giorno della settimana è obbligatorio.");
        if (oraApertura == null)
            throw new IllegalArgumentException("L'ora di apertura è obbligatoria.");
        if (oraChiusura == null)
            throw new IllegalArgumentException("L'ora di chiusura è obbligatoria.");
        if (!oraApertura.isBefore(oraChiusura))
            throw new IllegalArgumentException(
                    "L'ora di apertura (" + oraApertura + ") deve essere prima dell'ora di chiusura (" + oraChiusura + ").");

        this.giornoSettimana = giornoSettimana;
        this.oraApertura     = oraApertura;
        this.oraChiusura     = oraChiusura;
    }

    /**
     * Verifica se il ristorante risulta aperto dato il giorno e l'ora correnti.
     * Metodo di supporto: la logica isAperto() del Ristorante lo usa internamente.
     *
     * @param giorno giorno da verificare
     * @param ora    ora da verificare
     * @return true se il ristorante è aperto in quel momento
     */
    public boolean copreTempo(DayOfWeek giorno, LocalTime ora) {
        return this.giornoSettimana == giorno
                && ora.isAfter(oraApertura)
                && ora.isBefore(oraChiusura);
    }

    // --- Getter ---
    public Long getId()                   { return id; }
    public DayOfWeek getGiornoSettimana() { return giornoSettimana; }
    public LocalTime getOraApertura()     { return oraApertura; }
    public LocalTime getOraChiusura()     { return oraChiusura; }
    public Ristorante getRistorante()     { return ristorante; }

    // --- Setter (package-private: solo Ristorante imposta il back-reference) ---
    void setRistorante(Ristorante ristorante) { this.ristorante = ristorante; }

    public void setGiornoSettimana(DayOfWeek g) { this.giornoSettimana = g; }
    public void setOraApertura(LocalTime t)     { this.oraApertura = t; }
    public void setOraChiusura(LocalTime t)     { this.oraChiusura = t; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OrarioApertura)) return false;
        OrarioApertura other = (OrarioApertura) o;
        return id != null && id.equals(other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "OrarioApertura{" + giornoSettimana +
                " " + oraApertura + "-" + oraChiusura + '}';
    }
}
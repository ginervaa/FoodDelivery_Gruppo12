package entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Rappresenta un ordine effettuato da un Cliente verso un Ristorante.
 *
 * CICLO DI VITA DEGLI STATI (dalla traccia del progetto):
 *
 *   [INVIATO] ──accettaOrdine()──► [IN_PREPARAZIONE] ──avviaConsegna()──► [IN_CONSEGNA] ──confermaRicezione()──► [CONSEGNATO]
 *       │
 *       └──rifiutaOrdine()──► [RIFIUTATO]
 *
 * Le transizioni sono validate da StatoOrdine.puoTransireA(): qualsiasi
 * tentativo di transizione non valida lancia IllegalStateException.
 * Questo implementa la macchina a stati del Domain Model direttamente
 * nell'entity, che è il luogo corretto secondo GRASP Information Expert:
 * l'Ordine conosce il proprio stato e le regole per cambiarlo.
 *
 * RELAZIONI:
 *   Ordine N:1 Cliente   (cliente che ha effettuato l'ordine, FK cliente_id)
 *   Ordine N:1 Ristorante (ristorante che riceve l'ordine, FK ristorante_id)
 *   Ordine N:M Piatto    (piatti inclusi nell'ordine, tabella ordine_piatto)
 *
 * NOTA SU ordine_piatto vs carrello_piatto:
 * Sono due tabelle di join distinte e indipendenti. ordine_piatto rappresenta
 * uno snapshot dei piatti scelti al momento dell'ordine. Anche se il Ristoratore
 * in futuro modifica il Menu, l'ordine storico resta invariato.
 *
 * STATO INIZIALE:
 * Un Ordine viene sempre creato in stato INVIATO. Non ha senso costruire
 * un Ordine in uno stato diverso: nasce nel momento in cui il Cliente lo invia.
 */
@Entity
@Table(name = "ordine")
public class Ordine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String indirizzoConsegna;

    /**
     * Stato corrente del ciclo di vita dell'ordine.
     * EnumType.STRING: salva il nome letterale ("INVIATO", "IN_PREPARAZIONE" etc.)
     * invece dell'ordinale numerico. Più leggibile nel DB e robusto ai refactoring.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "stato_ordine", nullable = false, length = 20)
    private StatoOrdine statoOrdine;

    /**
     * Cliente che ha effettuato l'ordine.
     * Lato proprietario: questa tabella contiene la FK cliente_id.
     * nullable = false: un Ordine senza Cliente è semanticamente impossibile.
     */
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;

    /**
     * Ristorante che ha ricevuto l'ordine.
     * Lato proprietario: questa tabella contiene la FK ristorante_id.
     * nullable = false: un Ordine senza Ristorante è semanticamente impossibile.
     */
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "ristorante_id", nullable = false)
    private Ristorante ristorante;

    /**
     * Piatti inclusi nell'ordine.
     * Tabella di giunzione "ordine_piatto", separata da "carrello_piatto".
     * Rappresenta uno snapshot dei piatti al momento dell'ordine:
     * modifiche future al Menu non alterano gli ordini già inviati.
     * LAZY: i piatti vengono caricati dal DB solo quando richiesti.
     */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "ordine_piatto",
            joinColumns        = @JoinColumn(name = "ordine_id"),
            inverseJoinColumns = @JoinColumn(name = "piatto_id")
    )
    private List<Piatto> piatti = new ArrayList<>();

    /** Costruttore no-arg per Hibernate. */
    protected Ordine() {}

    /**
     * Costruttore principale con validazione difensiva.
     * Lo stato iniziale è sempre INVIATO: corrisponde al momento in cui
     * il Cliente conferma e invia l'ordine al sistema.
     *
     * param indirizzoConsegna indirizzo dove consegnare l'ordine
     * param cliente           il Cliente che effettua l'ordine
     * param ristorante        il Ristorante che riceve l'ordine
     * throws IllegalArgumentException se uno qualunque dei parametri è null o vuoto
     */
    public Ordine(String indirizzoConsegna, Cliente cliente, Ristorante ristorante) {
        if (indirizzoConsegna == null || indirizzoConsegna.isBlank())
            throw new IllegalArgumentException("L'indirizzo di consegna è obbligatorio.");
        if (cliente == null)
            throw new IllegalArgumentException("Il cliente non può essere null.");
        if (ristorante == null)
            throw new IllegalArgumentException("Il ristorante non può essere null.");

        this.indirizzoConsegna = indirizzoConsegna.trim();
        this.cliente           = cliente;
        this.ristorante        = ristorante;
        this.statoOrdine       = StatoOrdine.INVIATO; // stato iniziale sempre INVIATO
    }

    // --- Operazioni del Domain Model: gestione del ciclo di vita ---

    /**
     * Il Ristoratore accetta l'ordine.
     * Transizione: INVIATO → IN_PREPARAZIONE.
     * Corrisponde a accettaOrdine() del Domain Model.
     *
     * throws IllegalStateException se l'ordine non è in stato INVIATO
     */
    public void accettaOrdine() {
        transiziona(StatoOrdine.IN_PREPARAZIONE, "accettaOrdine");
    }

    /**
     * Il Ristoratore rifiuta l'ordine.
     * Transizione: INVIATO → RIFIUTATO.
     * Corrisponde a rifiutaOrdine() del Domain Model.
     *
     * throws IllegalStateException se l'ordine non è in stato INVIATO
     */
    public void rifiutaOrdine() {
        transiziona(StatoOrdine.RIFIUTATO, "rifiutaOrdine");
    }

    /**
     * Il Ristoratore avvia la consegna dell'ordine.
     * Transizione: IN_PREPARAZIONE → IN_CONSEGNA.
     * Corrisponde a avviaConsegna() del Domain Model.
     *
     * throws IllegalStateException se l'ordine non è in stato IN_PREPARAZIONE
     */
    public void avviaConsegna() {
        transiziona(StatoOrdine.IN_CONSEGNA, "avviaConsegna");
    }

    /**
     * Il Cliente conferma di aver ricevuto l'ordine.
     * Transizione: IN_CONSEGNA → CONSEGNATO.
     * Corrisponde a confermaRicezione() del Domain Model.
     *
     * throws IllegalStateException se l'ordine non è in stato IN_CONSEGNA
     */
    public void confermaRicezione() {
        transiziona(StatoOrdine.CONSEGNATO, "confermaRicezione");
    }

    /**
     * Aggiornamento generico dello stato con validazione.
     * Corrisponde a aggiornaStato() del Domain Model.
     * Usato dal Controller quando la transizione è determinata dinamicamente.
     *
     * param nuovoStato lo stato di destinazione desiderato
     * throws IllegalArgumentException se nuovoStato è null
     * throws IllegalStateException    se la transizione non è valida
     */
    public void aggiornaStato(StatoOrdine nuovoStato) {
        if (nuovoStato == null)
            throw new IllegalArgumentException("Il nuovo stato non può essere null.");
        transiziona(nuovoStato, "aggiornaStato");
    }

    /**
     * Metodo privato centrale per tutte le transizioni di stato.
     * Centralizza la logica di validazione in un unico punto (DRY).
     * La validità della transizione è delegata a StatoOrdine.puoTransireA().
     *
     * param target    stato di destinazione
     * param operazione nome dell'operazione chiamante (per il messaggio di errore)
     * throws IllegalStateException se la transizione non è consentita
     */
    private void transiziona(StatoOrdine target, String operazione) {
        if (!statoOrdine.puoTransireA(target)) {
            throw new IllegalStateException(
                    "Operazione '" + operazione + "' non valida: " +
                            "impossibile passare da [" + statoOrdine + "] a [" + target + "]. " +
                            "Ordine id=" + id
            );
        }
        this.statoOrdine = target;
    }

    /**
     * Aggiunge un Piatto all'ordine.
     * Tipicamente chiamato dal Controller quando copia i piatti dal Carrello.
     *
     * throws IllegalArgumentException se piatto è null
     */
    public void aggiungiPiatto(Piatto piatto) {
        if (piatto == null)
            throw new IllegalArgumentException("Il piatto non può essere null.");
        piatti.add(piatto);
    }

    // --- Getter ---

    public Long getId()                    { return id; }
    public String getIndirizzoConsegna()   { return indirizzoConsegna; }
    public StatoOrdine getStatoOrdine()    { return statoOrdine; }
    public Cliente getCliente()            { return cliente; }
    public Ristorante getRistorante()      { return ristorante; }

    /**
     * Restituisce una vista non modificabile dei piatti dell'ordine.
     * Un Ordine inviato non deve poter essere modificato direttamente
     * dall'esterno: solo aggiungiPiatto() è il punto di accesso controllato.
     */
    public List<Piatto> getPiatti() {
        return Collections.unmodifiableList(piatti);
    }

    /** Setter per l'indirizzo di consegna (es. modifica prima dell'invio). */
    public void setIndirizzoConsegna(String indirizzoConsegna) {
        if (indirizzoConsegna == null || indirizzoConsegna.isBlank())
            throw new IllegalArgumentException("L'indirizzo di consegna non può essere vuoto.");
        this.indirizzoConsegna = indirizzoConsegna.trim();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Ordine)) return false;
        Ordine other = (Ordine) o;
        return id != null && id.equals(other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Ordine{id=" + id +
                ", stato=" + statoOrdine +
                ", cliente=" + (cliente != null ? cliente.getUsername() : "null") +
                ", ristorante=" + (ristorante != null ? ristorante.getNome() : "null") +
                '}';
    }
}
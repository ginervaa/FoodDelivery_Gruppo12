package entity;

/**
 * Enumerazione degli stati del ciclo di vita di un Ordine.
 *
 * Le transizioni valide sono:
 *   INVIATO          → IN_PREPARAZIONE (accettaOrdine)
 *   INVIATO          → RIFIUTATO       (rifiutaOrdine)
 *   IN_PREPARAZIONE  → IN_CONSEGNA     (avviaConsegna)
 *   IN_CONSEGNA      → CONSEGNATO      (confermaRicezione)
 *
 * Qualsiasi altra transizione è illegale e viene bloccata nell'Ordine.
 * Questo enum non gestisce la logica direttamente: è l'Ordine
 * a fare la guardia. Qui definiamo solo i valori e un metodo
 * di supporto per la validazione.
 */
public enum StatoOrdine {
    INVIATO,
    IN_PREPARAZIONE,
    IN_CONSEGNA,
    CONSEGNATO,
    RIFIUTATO;

    /**
     * Verifica se la transizione da questo stato al targetStato è valida.
     * Centralizza la logica di transizione in un unico punto, evitando
     * che sia dispersa nei metodi di Ordine.
     *
     * target lo stato di destinazione desiderato
     * return true se la transizione è consentita
     */
    public boolean puoTransireA(StatoOrdine target) {
        if (target == null) return false;
        switch (this) {
            case INVIATO:
                return target == IN_PREPARAZIONE || target == RIFIUTATO;
            case IN_PREPARAZIONE:
                return target == IN_CONSEGNA;
            case IN_CONSEGNA:
                return target == CONSEGNATO;
            // CONSEGNATO e RIFIUTATO sono stati finali: nessuna transizione possibile
            case CONSEGNATO:
            case RIFIUTATO:
            default:
                return false;
        }
    }
}
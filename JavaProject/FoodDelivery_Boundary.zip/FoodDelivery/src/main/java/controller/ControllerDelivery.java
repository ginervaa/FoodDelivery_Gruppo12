package controller;

import java.util.ArrayList;
import java.util.List;

public class ControllerDelivery {


    public String registrazione(String username, String password, String ruolo,
                                String nome, String cognome, String email, String indirizzo) {return null;}

    public String login(String username, String password, String ruolo) {return null;}

    public String inserisciPiattoMenu(String nome, String descrizione, String prezzo) {
        return null;
    }

    public String modificaPiattoMenu(String nome, String descrizione, String prezzo) {
        return null;
    }

    public String rimuoviPiattoMenu(String nome) {
        return null;
    }

    public String aggiungiRistorante(String nome, String descrizione, String indirizzo) {return null;}

    public String modificaRistorante(String nome, String descrizione, String indirizzo) {return null;}

    public String rimuoviRistorante(String nome) {return null;}
}

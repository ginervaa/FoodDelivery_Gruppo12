package entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Carrello {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(mappedBy = "carrello")
    private Utente utente;

    @ManyToMany
    private List<Piatto> piatti = new ArrayList<>();

    public Carrello() {
    }

    public Long getId() {
        return id;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public List<Piatto> getPiatti() {
        return piatti;
    }

    public boolean aggiungiPiatto(Piatto piatto)
    {
        if (!piatti.isEmpty())
        {
            Piatto primoPiatto = piatti.get(0);

            Menu menuCorrente = primoPiatto.getMenu();
            Ristorante ristoranteCorrente = menuCorrente.getRistorante();

            Menu nuovoMenu = piatto.getMenu();
            Ristorante nuovoRistorante = nuovoMenu.getRistorante();

            if (!ristoranteCorrente.equals(nuovoRistorante)){ return false; }
        }

        piatti.add(piatto);
        return true;
    }

    public boolean rimuoviPiatto(Piatto piatto) { return piatti.remove(piatto); }

    public void svuota() { piatti.clear(); }
}
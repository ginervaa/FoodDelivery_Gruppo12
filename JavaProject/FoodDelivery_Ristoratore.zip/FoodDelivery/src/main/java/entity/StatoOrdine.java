package entity;

public enum StatoOrdine {
    INVIATO,
    IN_PREPARAZIONE,
    IN_CONSEGNA,
    CONSEGNATO,
    RIFIUTATO
}
package entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Ordine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String indirizzoDiConsegna;

    @Enumerated(EnumType.STRING)
    private StatoOrdine stato;

    @ManyToMany
    private List<Piatto> listaPiatti = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "ristorante_id")
    private Ristorante ristorante;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Utente cliente;

    public Ordine() {
    }

    public Ordine(List<Piatto> listaPiatti,
                  String indirizzoDiConsegna)
    {
        this.listaPiatti = listaPiatti;
        this.indirizzoDiConsegna = indirizzoDiConsegna;
        this.stato = StatoOrdine.INVIATO;
    }

    public Long getId() {
        return id;
    }

    public String getIndirizzoDiConsegna() {
        return indirizzoDiConsegna;
    }

    public List<Piatto> getListaPiatti() {
        return listaPiatti;
    }

    public StatoOrdine getStato() {
        return stato;
    }

    public void setStato(StatoOrdine stato) { this.stato = stato; }

    public Utente getCliente() {
        return cliente;
    }

    public void setCliente(Utente cliente) {
        this.cliente = cliente;
    }

    public Ristorante getRistorante() {
        return ristorante;
    }

    public void setRistorante(Ristorante ristorante) {
        this.ristorante = ristorante;
    }
}
package entity;

import java.util.List;
import java.util.ArrayList;

import jakarta.persistence.*;

@Entity
public class Ristorante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String descrizione;
    private String indirizzo;

    @ManyToOne
    @JoinColumn(name = "proprietario_id")
    private Utente proprietario;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "menu_id")
    private Menu menu;

    @OneToMany(mappedBy = "ristorante")
    private List<Ordine> ordini = new ArrayList<>();

    public Ristorante() {
    }

    public Ristorante(String nome,
                      String descrizione,
                      String indirizzo) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.indirizzo = indirizzo;
        this.menu = new Menu();
        this.menu.setRistorante(this);
    }

    public Long getId(){
        return id;
    }

    public Utente getProprietario(){
        return proprietario;
    }

    public void setProprietario(Utente proprietario) {
        this.proprietario = proprietario;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public String getNome(){
        return nome;
    }

    public String getDescrizione(){
        return descrizione;
    }

    public String getIndirizzo(){
        return indirizzo;
    }

    public Menu getMenu(){
        return menu;
    }

    public boolean aggiornaDatiRistorante(String nome,
                                          String descrizione,
                                          String indirizzo)
    {
        this.nome = nome;
        this.descrizione = descrizione;
        this.indirizzo = indirizzo;

        return true;
    }

}

package entity;

import database.GestorePersistenza;

import java.util.Map;

public class GestoreUtenti {

    private GestorePersistenza gestorePersistenza;

    public GestoreUtenti() {
        gestorePersistenza = new GestorePersistenza();
    }

    public Utente ricercaUtentePerUsername(String username) {

        return gestorePersistenza.cercaPrimoPerCampi(
                Utente.class,
                Map.of("username", username)
        );
    }

    public Utente ricercaUtentePerId(Long idUtente) {

        return gestorePersistenza.trovaPerId(
                Utente.class,
                idUtente
        );
    }

    public boolean creaUtente(
            String username,
            String password,
            RuoloUtente ruolo,
            String nome,
            String cognome,
            String email,
            String indirizzo)
    {

        if (ricercaUtentePerUsername(username) != null) {
            return false;
        }

        Utente nuovoUtente =
                new Utente(username, password, ruolo, nome,
                        cognome, email, indirizzo);

        return gestorePersistenza.salva(nuovoUtente);
    }
}
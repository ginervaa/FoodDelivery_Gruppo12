package entity;

import java.util.List;
import java.util.ArrayList;

import jakarta.persistence.*;

@Entity
public class Utente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String password;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "carrello_id")
    private Carrello carrello;

    @OneToMany(mappedBy = "proprietario")
    private List<Ristorante> ristoranti = new ArrayList<>();

    @OneToMany(mappedBy = "cliente")
    private List<Ordine> ordini = new ArrayList<>();

    @Enumerated(EnumType.STRING)
    private RuoloUtente ruolo;
    private String nome;
    private String cognome;
    private String email;
    private String indirizzo;

    public Utente() {
    }

    public Utente(String username,
                  String password,
                  RuoloUtente ruolo,
                  String nome,
                  String cognome,
                  String email,
                  String indirizzo)
    {
        this.username = username;
        this.password = password;
        this.ruolo = ruolo;
        this.nome = nome;
        this.cognome = cognome;
        this.email = email;
        this.indirizzo = indirizzo;

        if(ruolo == RuoloUtente.CLIENTE){
            this.carrello = new Carrello();
            this.carrello.setUtente(this);
        }
    }

    public boolean verificaCredenziali(String username,
                                       String password,
                                       RuoloUtente ruolo)
    {
        return this.username.equals(username)
                && this.password.equals(password)
                && this.ruolo == ruolo;
    }

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public RuoloUtente getRuolo() {
        return ruolo;
    }

    public Carrello getCarrello() {
        return carrello;
    }

    public void setCarrello(Carrello carrello) {
        this.carrello = carrello;
    }

    public List<Ristorante> getRistoranti() { return ristoranti; }

    public List<Ordine> getOrdini() { return ordini; }

    public String getPassword() { return password; }

    public String getNome() { return nome; }

    public String getCognome() { return cognome; }

    public String getEmail() { return email; }

    public String getIndirizzo() { return indirizzo; }
}
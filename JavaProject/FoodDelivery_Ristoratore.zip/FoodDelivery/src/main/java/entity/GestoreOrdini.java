package entity;

import database.GestorePersistenza;

import java.util.List;
import java.util.Map;

public class GestoreOrdini {

    private GestorePersistenza gestorePersistenza;

    public GestoreOrdini() {
        gestorePersistenza = new GestorePersistenza();
    }

    public List<Ordine> ricercaOrdiniInviatiPerRistorante(Long idRistorante)
    {
        return gestorePersistenza.cercaPerCampi(
                Ordine.class,
                Map.of(
                        "ristorante.id", idRistorante,
                        "stato", StatoOrdine.INVIATO
                )
        );
    }

    public boolean creaOrdine(Utente cliente,
                              Ristorante ristorante,
                              List<Piatto> listaPiatti,
                              String indirizzoConsegna)
    {
        Ordine ordine = new Ordine(listaPiatti, indirizzoConsegna);

        ordine.setCliente(cliente);
        ordine.setRistorante(ristorante);
        return gestorePersistenza.salva(ordine);
    }
}
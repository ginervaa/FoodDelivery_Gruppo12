package entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /*nell'esempio del professore, dice che
    FetchType.EAGER serve per evitare conflitti
    con la chiusura delle sessioni nelle interfacce,
    mentre CascadeType.ALL serve a ...
    */

    @OneToMany(mappedBy = "menu",
            fetch = FetchType.EAGER,
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private List<Piatto> piatti = new ArrayList<>();

    @OneToOne(mappedBy = "menu")
    private Ristorante ristorante;

    public Menu() {
    }

    public Long getId() { return id; }

    public List<Piatto> getListaPiatti() { return piatti; }

    public void setListaPiatti(List<Piatto> piatti) { this.piatti = piatti; }

    public Piatto ricercaPiatto(Long idPiatto)
    {
        for (Piatto piatto : piatti)
        {
            if(piatto.getId().equals(idPiatto)) { return piatto; }
        }
        return null;
    }

    public boolean aggiungiPiatto(String nome,
                                  String descrizione,
                                  float prezzo) {

        Piatto nuovoPiatto =
                new Piatto(nome, descrizione, prezzo);

        nuovoPiatto.setMenu(this);

        piatti.add(nuovoPiatto);
        return true;
    }

    public boolean aggiornaDatiPiatto(Long idPiatto,
                                      String nome,
                                      String descrizione,
                                      float prezzo) {

        for (Piatto piatto : piatti) {

            if (piatto.getId().equals(idPiatto)) {

                piatto.setNome(nome);
                piatto.setDescrizione(descrizione);
                piatto.setPrezzo(prezzo);
                return true;
            }
        }
        return false;
    }

    public boolean rimuoviPiatto(Long idPiatto) {

        Piatto piattoDaRimuovere = null;

        for (Piatto piatto : piatti) {

            if (piatto.getId().equals(idPiatto)) {
                piattoDaRimuovere = piatto;
                break;
            }
        }

        if (piattoDaRimuovere != null) {

            piatti.remove(piattoDaRimuovere);
            return true;
        }
        return false;
    }

    public Ristorante getRistorante() {
        return ristorante;
    }

    public void setRistorante(Ristorante ristorante) {
        this.ristorante = ristorante;
    }
}
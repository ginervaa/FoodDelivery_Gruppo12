package entity;

import database.GestorePersistenza;

import java.util.List;

public class GestoreRistoranti {

    private GestorePersistenza gestorePersistenza;

    public GestoreRistoranti() {
        gestorePersistenza = new GestorePersistenza();
    }

    public Ristorante ricercaRistorantePerId(Long idRistorante)
    {
        return gestorePersistenza.trovaPerId(
                Ristorante.class,
                idRistorante
        );
    }

    public List<Ristorante> ricercaRistorantiPerProprietario(Utente proprietario)
    {
        return gestorePersistenza.cercaPerCampo(
                Ristorante.class,
                "proprietario",
                proprietario
        );
    }

    public Ristorante creaRistorante(Utente proprietario,
                                  String nome,
                                  String descrizione,
                                  String indirizzo)
    {
        Ristorante ristorante = new Ristorante(nome, descrizione, indirizzo);
        ristorante.setProprietario(proprietario);

        boolean salvato = gestorePersistenza.salva(ristorante);
        if(salvato){ return ristorante; }
        return null;
    }

    public boolean aggiornaRistorante(Ristorante ristorante)
    {
        return gestorePersistenza.aggiorna(ristorante) != null;
    }

    public Ristorante aggiornaRistoranteRestituendoOggetto(Ristorante ristorante) {
        return gestorePersistenza.aggiorna(ristorante);
    }

    public boolean rimuoviRistorante(Long idRistorante)
    {
        return gestorePersistenza.elimina(
                Ristorante.class,
                idRistorante
        );
    }
}
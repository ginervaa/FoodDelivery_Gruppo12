package entity;

import java.util.List;
import java.util.ArrayList;

import jakarta.persistence.*;

@Entity
public class Piatto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String descrizione;
    private float prezzo;

    @ManyToOne
    @JoinColumn(name = "menu_id")
    private Menu menu;

    @ManyToMany(mappedBy = "listaPiatti")
    private List<Ordine> ordini = new ArrayList<>();

    public Piatto() {
    }

    public Piatto(String nome,
                  String descrizione,
                  float prezzo)
    {
        this.nome = nome;
        this.descrizione = descrizione;
        this.prezzo = prezzo;
    }

    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }
}
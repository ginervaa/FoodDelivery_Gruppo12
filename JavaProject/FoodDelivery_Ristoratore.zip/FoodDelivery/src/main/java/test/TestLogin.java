package test;

import entity.GestoreUtenti;
import entity.Utente;

public class TestLogin {

    public static void main(String[] args) {

        GestoreUtenti gestoreUtenti = new GestoreUtenti();

        Utente u =
                gestoreUtenti.ricercaUtentePerUsername("mario");

        if(u != null){
            System.out.println("Trovato utente:");
            System.out.println(u.getUsername());
            System.out.println(u.getRuolo());
        }
        else{
            System.out.println("Utente non trovato");
        }
    }
}
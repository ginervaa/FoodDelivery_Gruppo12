package test;

import entity.GestoreUtenti;
import entity.RuoloUtente;
import entity.Utente;

public class TestDatabase {

    public static void main(String[] args) {

        GestoreUtenti gestoreUtenti =
                new GestoreUtenti();

        Utente u = gestoreUtenti.ricercaUtentePerId(1L);

        System.out.println(u.getUsername());
    }
}
package controller;

import entity.*;

import java.util.ArrayList;
import java.util.List;

public class ControllerDelivery {

    // Variabile che serve a gestire la sessione.
    private static Long idUtenteLoggato = null;

    // Restituisce alla GUI (Boundary) la lista dei ristoranti di cui l'utente loggato è proprietario.
    public static List<String[]> ottieniRistoranti(){

        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // Il GestoreRistoranti restituisce una lista di ristoranti appartenenti all'utente loggato.
        GestoreUtenti gestoreUtenti = new GestoreUtenti();

        Utente utente = gestoreUtenti.ricercaUtentePerId(idUtenteLoggato);

        List<Ristorante> ristoranti =
                gestoreRistoranti.ricercaRistorantiPerProprietario(utente);
        // La lista da restituire alla Boundary, ogni elemento è una riga della tabella nel DB.
        List<String[]> righe = new ArrayList<>();

        // Converto la lista di elementi Ristorante in una lista di String, che verrà restituita alla Boundary.
        for (Ristorante ristorante : ristoranti) {

            String[] riga = new String[]{
                    String.valueOf(ristorante.getId()),
                    ristorante.getNome(),
                    ristorante.getDescrizione(),
                    ristorante.getIndirizzo()
            };

            righe.add(riga);
        }

        return righe;
    }

    // Realizza il caso d'uso "Creazione Profilo Ristorante".
    public static Long creaProfiloRistorante(String nome,
                                                String descrizione,
                                                String indirizzo)
    {
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        GestoreUtenti gestoreUtenti = new GestoreUtenti();
        Utente utente = gestoreUtenti.ricercaUtentePerId(idUtenteLoggato);

        //il gestore crea un nuovo ristorante
        Ristorante nuovoRistorante = gestoreRistoranti.creaRistorante(
                utente,
                nome,
                descrizione,
                indirizzo
        );

        //se non è nullo, il salvataggio è andato a buon fine
        if(nuovoRistorante != null){
            return nuovoRistorante.getId();
        }
        return null;
    }

    // Realizza il caso d'uso "Modifica Profilo Ristorante".
    public static boolean aggiornaProfiloRistorante(Long idRistorante,
                                                    String nome,
                                                    String descrizione,
                                                    String indirizzo)
    {
        // Genero una istanza di GestoreRistoranti.
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Controllo per verificare che il ristorante restituito non sia nullo.
        if (ristorante == null){ return false; }

        // L'aggiornamento dei dati del ristorante ritorna "true" se va a buon fine.
        ristorante.aggiornaDatiRistorante(nome, descrizione, indirizzo);

        return gestoreRistoranti.aggiornaRistorante(ristorante);
    }

    public static boolean rimuoviRistorante(Long idRistorante)
    {
        boolean esito;

        // Genero una istanza di GestoreRistoranti.
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante =
                gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Controllo per verificare che il ristorante restituito non sia nullo.
        if (ristorante == null){
            return false;
        }

        // La rimozione restituisce true se va a buon fine.
        esito = gestoreRistoranti.rimuoviRistorante(idRistorante);

        return esito;
    }

    // Realizza il caso d'uso "Gestione Menu Inserimento Piatto".
    public static boolean inserisciPiattoMenu(Long idRistorante,
                                              String nome,
                                              String descrizione,
                                              float prezzo)
    {
        // Genero una istanza di GestoreRistoranti.
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Controllo per verificare che il ristorante restituito non sia nullo.
        if (ristorante == null){ return false; }

        // Ottengo l'istanza del menu del ristorante ricercato.
        Menu menu = ristorante.getMenu();

        //crea il piatto
        Piatto nuovoPiatto = new Piatto(nome, descrizione, prezzo);

        //Menu aggiunge il piatto in memoria
        nuovoPiatto.setMenu(menu);
        menu.getListaPiatti().add(nuovoPiatto);

        return gestoreRistoranti.aggiornaRistorante(ristorante);
    }

    // Realizza il caso d'uso "Gestione Menu Modifica Piatto".
    public static boolean modificaPiattoMenu(Long idRistorante,
                                             Long idPiatto,
                                             String nome,
                                             String descrizione,
                                             float prezzo)
    {
        boolean esito;

        // Genero una istanza di GestoreRistoranti.
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Controllo per verificare che il ristorante restituito non sia nullo.
        if (ristorante == null){
            return false;
        }

        // Ottengo l'istanza del menu del ristorante ricercato.
        Menu menu = ristorante.getMenu();

        // L'aggiornamento dei dati del piatto restituisce "true" se va a buon fine.
        esito = menu.aggiornaDatiPiatto(idPiatto, nome, descrizione, prezzo);

        if(!esito){ return false; }
        return gestoreRistoranti.aggiornaRistorante(ristorante);
    }

    // Realizza il caso d'uso "Gestione Menu Elimina Piatto".
    public static boolean eliminaPiattoMenu(Long idRistorante,
                                            Long idPiatto)
    {
        boolean esito;

        // Genero una istanza di GestoreRistoranti.
        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Controllo per verificare che il ristorante restituito non sia nullo.
        if (ristorante == null){
            return false;
        }

        // Ottengo l'istanza del menu del ristorante ricercato.
        Menu menu = ristorante.getMenu();

        // Se l'eliminazione va a buon fine, restituisce "true".
        esito = menu.rimuoviPiatto(idPiatto);

        if (!esito) { return false; }

        return gestoreRistoranti.aggiornaRistorante(ristorante);
    }

    // Realizza il caso d'uso "Registrazione Utente".
    public static boolean registrazione(String username,
                                        String password,
                                        RuoloUtente ruolo,
                                        String nome,
                                        String cognome,
                                        String email,
                                        String indirizzo)
    {
        boolean esito;

        // Genero una istanza di GestoreUtenti.
        GestoreUtenti gestoreUtenti = new GestoreUtenti();

        // La creazione dell'utente restituisce true se va a buon fine.
        esito = gestoreUtenti.creaUtente(
                username,
                password,
                ruolo,
                nome,
                cognome,
                email,
                indirizzo
        );

        return esito;
    }

    // Realizza il caso d'uso "Accesso Utente".
    public static boolean login(String username,
                                String password,
                                RuoloUtente ruolo)
    {
        boolean esito;

        // Genero una istanza di GestoreUtenti.
        GestoreUtenti gestoreUtenti = new GestoreUtenti();

        // GestoreUtenti restituisce l'oggetto Utente ricercato in base all'username.
        Utente utente = gestoreUtenti.ricercaUtentePerUsername(username);

        // Controllo per verificare che l'Utente restituito non sia nullo.
        if (utente == null){
            return false;
        }

        // La verifica delle credenziali restituisce "true" se queste sono corrette.
        esito = utente.verificaCredenziali(username, password, ruolo);

        // Aggiorno la variabile interna del controller per gestire l'utente loggato.
        if (esito == true){
            idUtenteLoggato = utente.getId();
        }

        return esito;
    }

    // Restituisce alla GUI (Boundary) la lista dei piatti presenti nel menu di un ristorante.
    public static List<String[]> ottieniPiatti(Long idRistorante){

        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();

        // GestoreRistoranti restituisce l'oggetto Ristorante ricercato in base all'id.
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);

        // Il GestoreRistoranti restituisce una lista di ristoranti appartenenti all'utente loggato.
        List<Piatto> piatti = ristorante.getMenu().getListaPiatti();

        // La lista da restituire alla Boundary, ogni elemento è una riga della tabella nel DB.
        List<String[]> righe = new ArrayList<>();

        // Converto la lista di elementi Piatto in una lista di String, che verrà restituita alla Boundary.
        for (Piatto piatto : piatti) {

            String[] riga = new String[]{
                    String.valueOf(piatto.getId()),
                    piatto.getNome(),
                    piatto.getDescrizione(),
                    String.valueOf(piatto.getPrezzo())
            };

            righe.add(riga);
        }

        return righe;
    }

    // Permette all'utente di aggiungere un piatto al proprio carrello, fa parte del caso d'uso "Effettua Ordine".
    public static boolean aggiungiPiattoCarrello(Long idRistorante,
                                                 Long idPiatto)
    {
        GestoreUtenti gestoreUtenti = new GestoreUtenti();
        Utente utente = gestoreUtenti.ricercaUtentePerId(idUtenteLoggato);
        if (utente == null) { return false; }

        Carrello carrello = utente.getCarrello();
        if (carrello == null) { return false; }

        GestoreRistoranti gestoreRistoranti = new GestoreRistoranti();
        Ristorante ristorante = gestoreRistoranti.ricercaRistorantePerId(idRistorante);
        if (ristorante == null) { return false; }

        Menu menu = ristorante.getMenu();
        Piatto piatto = menu.ricercaPiatto(idPiatto);
        if (piatto == null) { return false; }

        return carrello.aggiungiPiatto(piatto);
    }

    // Permette di inviare l'ordine, fa parte del caso d'uso "Effettua Ordine".
    public static boolean ordina(String indirizzo)
    {
        GestoreUtenti gestoreUtenti = new GestoreUtenti();
        GestoreOrdini gestoreOrdini = new GestoreOrdini();

        Utente utente = gestoreUtenti.ricercaUtentePerId(idUtenteLoggato);
        if (utente == null) { return false; }

        Carrello carrello = utente.getCarrello();
        if (carrello == null) { return false; }

        List<Piatto> piatti = carrello.getPiatti();
        if (piatti.isEmpty()) { return false; }

        Piatto primoPiatto = piatti.get(0);
        Menu menu = primoPiatto.getMenu();
        Ristorante ristorante = menu.getRistorante();
        boolean esito = gestoreOrdini.creaOrdine(utente, ristorante,
                                                piatti, indirizzo);

        if (esito) { piatti.clear(); }
        return esito;
    }

    // Restituisce alla GUI (Boundary) gli ordini in entrata di un ristorante.
    // Fa parte del caso d'uso "Gestione Ordini Ricevuti".
    public static List<String[]> ottieniOrdiniRicevuti(Long idRistorante)
    {
        // Genero una istanza di GestoreOrdini.
        GestoreOrdini gestoreOrdini = new GestoreOrdini();

        // GestoreOrdini restituisce la lista degli ordini in stato "Inviato" in base all'id del Ristorante.
        List<Ordine> ordiniInviati = gestoreOrdini.ricercaOrdiniInviatiPerRistorante(idRistorante);

        // La lista da restituire alla Boundary, ogni elemento è una riga della tabella nel DB.
        List<String[]> righe = new ArrayList<>();

        // Converto la lista di elementi Piatto in una lista di String, che verrà restituita alla Boundary.
        for (Ordine ordine : ordiniInviati) {

            String[] riga = new String[]{
                    String.valueOf(ordine.getId()),
                    ordine.getIndirizzoDiConsegna(),
                    // NOTA: Per ora, nella GUI l'utente ristoratore vedrà solo il numero di piatti.
                    String.valueOf(ordine.getListaPiatti().size())
            };

            righe.add(riga);
        }

        return righe;
    }

}

package Controller;

import Entity.RuoloUtente;
import Entity.Utente;
import Entity.Gestori.GestoreUtenti;

public class ControllerSessione {

    /* Tengo un riferimento fisso all'utente loggato, in modo che l'istanza Utente dell'utente
       attualmente loggato non venga persa. Serve a gestire la sessione attuale. */
    public static Utente utenteLoggato;

    // Restituisce "true" se il login va a buon fine.
    public static boolean login(String username,
                                String password,
                                RuoloUtente ruolo)
    {
        boolean esito;

        // Genero una istanza di GestoreUtenti.
        GestoreUtenti gestoreUtenti = new GestoreUtenti();

        // GestoreUtenti restituisce l'oggetto Utente ricercato in base all'username.
        Utente utente = gestoreUtenti.ricercaUtentePerUsername(username);

        // Controllo per verificare che l'Utente restituito non sia nullo.
        if (utente == null){
            return false;
        }

        // La verifica delle credenziali restituisce "true" se queste sono corrette.
        esito = utente.verificaCredenziali(username, password, ruolo);

        // Aggiorno la variabile interna del controller per gestire l'utente loggato.
        if (esito == true){
            System.out.println("LOGIN CON SUCCESSO!");
            ControllerSessione.utenteLoggato = utente;
        }

        return esito;
    }

}

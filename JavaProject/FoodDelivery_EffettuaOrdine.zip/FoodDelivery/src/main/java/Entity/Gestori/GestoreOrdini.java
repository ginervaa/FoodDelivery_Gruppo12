package Entity.Gestori;

import Database.GestorePersistenza;
import Entity.*;
import Entity.StatoOrdine.StatoInviato;

import java.util.List;

// Questa classe è Information Expert della classe Ordine, non diventerà una tabella nel DB.
public class GestoreOrdini {

    // Il GestoreOrdini ha una propria istanza del GestorePersistenza.
    GestorePersistenza gestorePersistenza;

    /* Il GestoreOrdini possiede una lista degli ordini, tuttavia in questo codice, poiché
           il GestoreOrdini si interfaccia direttamente con il database, è superflua. */
    // private List<Ordine> ordini;

    // Costruttore di GestoreOrdini.
    public GestoreOrdini() {
        // Ogni volta che un GestoreOrdini viene istanziato, viene istanziato anche il suo GestorePersistenza.
        gestorePersistenza = new GestorePersistenza();
    }

    // Crea un oggetto Ordine e lo salva nel DB, restituisce true se l'inserimento va a buon fine.
    public boolean creaOrdine(Cliente cliente,
                              Ristorante ristorante,
                              String indirizzoConsegna)
    {
        // Preleva automaticamente il carrello e la lista dei piatti dall'oggetto Cliente.
        Carrello carrello = cliente.getCarrello();
        List<Piatto> listaPiatti = carrello.getPiatti();

        // Verifica che il carrello non sia vuoto.
        if (listaPiatti.isEmpty()) {
            return false;
        }

        // Crea il nuovo oggetto Ordine con lo stato "INVIATO".
        Ordine ordine = new Ordine(cliente, ristorante, listaPiatti,indirizzoConsegna, new StatoInviato());

        // Salva l'oggetto Ordine nel DB.
        return gestorePersistenza.salva(ordine);
    }

}

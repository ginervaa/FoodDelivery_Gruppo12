package Setup;

import Boundary.EffettuaOrdine.FrameRistorantiAperti;
import Controller.ControllerSessione;
import Database.JpaUtil;
import Entity.RuoloUtente;

public class MainInizializzaDatabase {

    public static void main(String[] args) {

        /*
         * Avvia Hibernate.
         *
         * Con hibernate.hbm2ddl.auto = update, Hibernate crea o aggiorna
         * le tabelle senza cancellare i dati già presenti.
         *
         * Con hibernate.hbm2ddl.auto = create, Hibernate elimina e ricrea
         * le tabelle a ogni avvio dell'applicazione.
         */
        JpaUtil.getInstance();

        // Popolamento di alcuni utenti per test.
        DatiTestDelivery.popolaUtenti();

        // Popolamento di ristoranti e piatti per test.
        DatiTestDelivery.popolaRistoranti();

        // Effettuo il login come utente "silvato", senza farlo manualmente con la GUI.
        ControllerSessione.login("silvato","silvato", RuoloUtente.CLIENTE);

        // Avvio il frame di ricerca ristoranti aperti, cioè la finestra.
        FrameRistorantiAperti frameRistorantiAperti = new FrameRistorantiAperti();
        frameRistorantiAperti.apriFrameRistorantiAperti();
    }
}
